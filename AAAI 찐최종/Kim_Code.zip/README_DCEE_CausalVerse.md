# DCEE-CausalVerse Code Execution Guide

This document describes how to install the required dependencies, configure the execution environment, run the DCEE-CausalVerse model, and evaluate the generated results.

The code was tested successfully in a newly created virtual environment using the hardware and software environment described below.

---

## 1. Tested Environment

### Development Tool

- Visual Studio Code (VS Code)
- Windows PowerShell

### Hardware

- GPU: NVIDIA GeForce RTX 3090 Ti
- GPU Memory: 24 GB

### Estimated Runtime

- Main DCEE-CausalVerse generation: approximately 1 hour
- Evaluation metrics: approximately 1 minute

Runtime may vary depending on the hardware environment, installed library versions, system load, and generation settings.

---

## 2. Create and Activate a Virtual Environment

Create a Python virtual environment before installing the required libraries.

The following example assumes that the virtual environment is named `ft_260731`.

```powershell
python -m venv ft_260731
.\ft_260731\Scripts\Activate.ps1
```

After activation, move to the project directory.

```powershell
cd final_test
```

> If PowerShell prevents script execution, the execution policy may need to be changed for the current session:
>
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> ```

---

## 3. Install the Required Libraries

Upgrade `pip` and install the required Python libraries using the provided requirements file.

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements_cq2.txt
```

---

## 4. Verify the Import Paths

This step checks whether the Python import paths and command-line interfaces are configured correctly.

This verification step is optional and may be skipped when the environment has already been tested.

```powershell
$env:PYTHONPATH="."

python run_v63_1_CQ2.py --help
python scripts\evaluate_output_metrics.py --help
```

If both commands display their help messages without import errors, the environment is configured correctly.

---

## 5. Configure the OpenAI API

The DCEE-CausalVerse pipeline uses the OpenAI API during execution.

Set the following environment variables in PowerShell:

```powershell
$env:OPENAI_API_KEY="your_openai_api_key"
$env:OPENAI_BASE_URL="https://api.openai.com/v1"
$env:OPENAI_MODEL="gpt-4o-mini"
$env:OPENAI_VLM_MODEL="gpt-4o-mini"
$env:PYTHONPATH="."
```

Replace `your_openai_api_key` with a valid OpenAI API key.

In the tested configuration, one complete execution used approximately USD 1 of OpenAI API credits. The actual cost may vary depending on API pricing, the number of retries, generated tokens, and execution settings.

---

## 6. Run the Main DCEE-CausalVerse Model

The following command runs the main DCEE-CausalVerse generation pipeline using the provided configuration and input files.

```powershell
$env:PYTHONPATH="."

$sw = [System.Diagnostics.Stopwatch]::StartNew()

python run_v63_1_CQ2.py `
  --config configs\config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml `
  --input examples\white_bear_reference_text_anchor_v63_1.json `
  --out outputs\V63_1_3090_white_bear_CQ2_finaltest_1

$sw.Stop()
"Elapsed: {0}" -f $sw.Elapsed
```

The backtick character (`` ` ``) is used in PowerShell to split a long command across multiple lines.

The same command may also be executed on a single line:

```powershell
python run_v63_1_CQ2.py --config configs\config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml --input examples\white_bear_reference_text_anchor_v63_1.json --out outputs\V63_1_3090_white_bear_CQ2_finaltest_1
```

On an RTX 3090 Ti with 24 GB of GPU memory, the tested execution required approximately 1 hour.

---

## 7. Run the Evaluation Metrics

After the main generation process is complete, run the following command to calculate CLIP-I, CLIP-T, and TIFA.

```powershell
python scripts\evaluate_output_metrics.py `
  --output V63_1_3090_white_bear_CQ2_finaltest_1 `
  --reference-image examples\images\w_bear_1.png `
  --no-fid `
  --local-files-only
```

The same command may also be executed on a single line:

```powershell
python scripts\evaluate_output_metrics.py --output V63_1_3090_white_bear_CQ2_finaltest_1 --reference-image examples\images\w_bear_1.png --no-fid --local-files-only
```

The evaluation process takes approximately 1 minute in the tested environment.

### Evaluated Metrics

- **CLIP-I:** image-to-image similarity between the generated images and the reference image
- **CLIP-T:** image-to-text alignment between the generated images and their corresponding textual descriptions
- **TIFA:** text-to-image faithfulness evaluation
- **FID:** not calculated because the `--no-fid` option is enabled

---

## 8. Check the Generated Results

The generated files are stored in the output directory created during execution.

For the example command above, the main output directory is:

```text
outputs/
└── V63_1_3090_white_bear_CQ2_finaltest_1/
```

The primary result files and directories are as follows:

```text
V63_1_3090_white_bear_CQ2_finaltest_1/
├── contact_sheet.png
├── frames/
├── ending_candidates/
├── final_story.md
├── metric_report.md
└── metric_report.json
```

### Output Description

| File or Directory | Description |
|---|---|
| `contact_sheet.png` | Final selected six-frame image sequence |
| `frames/` | Images generated for Frames 1–5 |
| `ending_candidates/` | Candidate images generated for Frame 6 |
| `final_story.md` | Story generated by the DCEE-CausalVerse pipeline |
| `metric_report.md` | Human-readable evaluation report |
| `metric_report.json` | Machine-readable evaluation results |

---

## 9. Complete Execution Example

The following PowerShell commands summarize the complete execution procedure.

```powershell
# Activate the virtual environment.
.\ft_260731\Scripts\Activate.ps1

# Move to the project directory.
cd final_test

# Install the required libraries.
python -m pip install --upgrade pip
python -m pip install -r requirements_cq2.txt

# Configure the API and Python import path.
$env:OPENAI_API_KEY="your_openai_api_key"
$env:OPENAI_BASE_URL="https://api.openai.com/v1"
$env:OPENAI_MODEL="gpt-4o-mini"
$env:OPENAI_VLM_MODEL="gpt-4o-mini"
$env:PYTHONPATH="."

# Run DCEE-CausalVerse.
$sw = [System.Diagnostics.Stopwatch]::StartNew()

python run_v63_1_CQ2.py `
  --config configs\config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml `
  --input examples\white_bear_reference_text_anchor_v63_1.json `
  --out outputs\V63_1_3090_white_bear_CQ2_finaltest_1

$sw.Stop()
"Elapsed: {0}" -f $sw.Elapsed

# Calculate CLIP-I, CLIP-T, and TIFA.
python scripts\evaluate_output_metrics.py `
  --output V63_1_3090_white_bear_CQ2_finaltest_1 `
  --reference-image examples\images\w_bear_1.png `
  --no-fid `
  --local-files-only
```

---

## 10. Notes

- Run all commands from the project root directory unless otherwise specified.
- The provided commands are written for Windows PowerShell.
- Make sure that the virtual environment is activated before installing libraries or running the code.
- The tested GPU environment was an RTX 3090 Ti with 24 GB of VRAM.
- Systems with less GPU memory may encounter out-of-memory errors.
- Generated outputs may differ slightly because the pipeline includes stochastic image generation.
- API cost and runtime may vary depending on the generation configuration and the number of retries.
