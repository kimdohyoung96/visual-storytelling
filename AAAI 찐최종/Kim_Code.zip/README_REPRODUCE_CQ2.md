# DCEE-CausalVerse CQ2 Reproduction Package

This folder contains the main DCEE-CausalVerse CQ2 code path and the metric
script used for the white bear experiment. Baseline/comparison model code is
not included in this package.

## Contents

- `run_v63_1_CQ2.py`: main model entry point
- `configs/config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml`: RTX 3090 CQ2 config
- `examples/white_bear_reference_text_anchor_v63_1.json`: white bear input sample
- `examples/images/w_bear_1.png`: reference image for CLIP-I evaluation
- `src/dce_vistory/`: DCEE-CausalVerse implementation modules
- `scripts/evaluate_output_metrics.py`: CLIP-I, CLIP-T, and TIFA-style evaluation script
- `requirements_cq2.txt`: package versions from the reproduction environment

## Environment

Recommended environment:

- Windows PowerShell
- Python 3.12
- NVIDIA GPU with at least 24 GB VRAM
- CUDA-compatible PyTorch
- OpenAI API key for LLM/VLM stages and TIFA-style evaluation
- Hugging Face access/cache for SDXL and CLIP model weights

Create the virtual environment from inside this folder:

```powershell
.\setup_venv.ps1
```

If PyTorch installation fails, install a CUDA build matching the target machine
from the official PyTorch instructions, then install the remaining requirements.

## OpenAI Variables

```powershell
$env:OPENAI_API_KEY="YOUR_API_KEY"
$env:OPENAI_BASE_URL="https://api.openai.com/v1"
$env:OPENAI_MODEL="gpt-4o-mini"
$env:OPENAI_VLM_MODEL="gpt-4o-mini"
```

## Run Main Model

```powershell
.\run_main_cq2.ps1
```

Equivalent explicit command:

```powershell
$env:PYTHONPATH="."
$sw = [System.Diagnostics.Stopwatch]::StartNew()
.\.venv_cq2_final\Scripts\python.exe run_v63_1_CQ2.py --config configs\config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml --input examples\white_bear_reference_text_anchor_v63_1.json --out outputs\V63_1_3090_white_bear_CQ2_1
$sw.Stop()
"Elapsed: {0}" -f $sw.Elapsed
```

The selected frames and story metadata are written under:

```text
outputs/V63_1_3090_white_bear_CQ2_1
```

## Run Metrics

FID is intentionally disabled in this reproduction command because this sample
has a single reference image, not a real-image distribution.

```powershell
.\run_metrics_cq2.ps1
```

Equivalent explicit command:

```powershell
$env:PYTHONPATH="."
.\.venv_cq2_final\Scripts\python.exe scripts\evaluate_output_metrics.py --output V63_1_3090_white_bear_CQ2_1 --reference-image examples\images\w_bear_1.png --no-fid --local-files-only
```

The metric report is written to:

```text
outputs/V63_1_3090_white_bear_CQ2_1/metric_report.json
outputs/V63_1_3090_white_bear_CQ2_1/metric_report.md
```
