param(
    [string]$Out = "outputs\V63_1_3090_white_bear_CQ2_1"
)

$env:PYTHONPATH="."

$sw = [System.Diagnostics.Stopwatch]::StartNew()
.\.venv_cq2_final\Scripts\python.exe run_v63_1_CQ2.py `
    --config configs\config_v63_1_signature_emotion_storycore_hotfix_3090_CQ2.yaml `
    --input examples\white_bear_reference_text_anchor_v63_1.json `
    --out $Out
$sw.Stop()
"Elapsed: {0}" -f $sw.Elapsed
