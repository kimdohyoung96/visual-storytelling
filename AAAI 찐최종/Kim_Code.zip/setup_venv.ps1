python -m venv .venv_cq2_final
.\.venv_cq2_final\Scripts\python.exe -m pip install --upgrade pip
.\.venv_cq2_final\Scripts\python.exe -m pip install -r requirements_cq2.txt
