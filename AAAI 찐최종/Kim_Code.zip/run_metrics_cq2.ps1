param(
    [string]$Output = "V63_1_3090_white_bear_CQ2_1",
    [string]$ReferenceImage = "examples\images\w_bear_1.png"
)

$env:PYTHONPATH="."

.\.venv_cq2_final\Scripts\python.exe scripts\evaluate_output_metrics.py `
    --output $Output `
    --reference-image $ReferenceImage `
    --no-fid `
    --local-files-only
