from __future__ import annotations

import argparse
import base64
import json
import math
import mimetypes
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import numpy as np
from PIL import Image


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def _clean(x: Any) -> str:
    return re.sub(r"\s+", " ", str(x or "")).strip()


def _read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _resolve_path(path_text: Any, base_dir: Path | None = None) -> Optional[Path]:
    text = _clean(path_text)
    if not text:
        return None
    p = Path(text)
    candidates = [p]
    if not p.is_absolute():
        if base_dir is not None:
            candidates.append(base_dir / p)
        candidates.append(Path.cwd() / p)
    for cand in candidates:
        if cand.exists():
            return cand.resolve()
    return None


def _image_paths_in_dir(path: Path) -> List[Path]:
    if not path.exists():
        return []
    return sorted([p for p in path.rglob("*") if p.suffix.lower() in IMAGE_EXTS and p.is_file()])


def resolve_output_dir(output: str, outputs_root: str = "outputs") -> Path:
    raw = Path(output)
    candidates = [raw]
    if not raw.is_absolute():
        candidates.append(Path(outputs_root) / output)
    for cand in candidates:
        if cand.exists() and cand.is_dir():
            return cand.resolve()
    raise FileNotFoundError(f"Output folder not found: {output}")


@dataclass
class FrameRecord:
    frame_id: int
    image_path: Path
    caption: str
    prompt: str


def _storyboard_caption_map(out_dir: Path) -> Dict[int, str]:
    rows = _read_json(out_dir / "storyboard.json", []) or []
    out: Dict[int, str] = {}
    if isinstance(rows, list):
        for idx, row in enumerate(rows, 1):
            if not isinstance(row, dict):
                continue
            frame_id = int(row.get("frame_id") or idx)
            out[frame_id] = _clean(
                row.get("story_sentence")
                or row.get("image_caption_en")
                or row.get("caption")
                or row.get("full_story_sentence")
            )
    return out


def load_selected_frames(out_dir: Path) -> List[FrameRecord]:
    selected = _read_json(out_dir / "selected_images.json", []) or []
    captions = _storyboard_caption_map(out_dir)
    frames: List[FrameRecord] = []
    if isinstance(selected, list) and selected:
        for idx, row in enumerate(selected, 1):
            if not isinstance(row, dict):
                continue
            frame_id = int(row.get("frame_id") or idx)
            image_path = _resolve_path(row.get("image_path"), None)
            if image_path is None:
                image_path = _resolve_path(row.get("image_path"), out_dir)
            if image_path is None:
                continue
            notes = row.get("notes") or {}
            spec = notes.get("frame_visual_spec") or {}
            caption = _clean(
                spec.get("story_sentence")
                or notes.get("current_story_sentence")
                or row.get("story_sentence")
                or row.get("caption")
                or captions.get(frame_id)
                or row.get("prompt")
            )
            frames.append(FrameRecord(frame_id=frame_id, image_path=image_path, caption=caption, prompt=_clean(row.get("prompt"))))
    else:
        frames.extend(load_baseline_frames(out_dir))
    frames.sort(key=lambda x: x.frame_id)
    if not frames:
        raise ValueError(f"No selected frame images found in {out_dir}")
    return frames


def _baseline_result_path(out_dir: Path) -> Optional[Path]:
    for name in ["sdxl_base_result.json", "ip_adapter_sdxl_result.json"]:
        p = out_dir / name
        if p.exists():
            return p
    matches = sorted(out_dir.glob("*result.json"))
    return matches[0] if matches else None


def _captions_from_input(input_source: Any, out_dir: Path) -> Dict[int, str]:
    if isinstance(input_source, dict):
        data = input_source
    else:
        p = _resolve_path(input_source, out_dir)
        if p is None:
            return {}
        data = _read_json(p, {}) or {}
    out: Dict[int, str] = {}
    rows = data.get("frame_captions") or data.get("frame_prompts") or []
    if isinstance(rows, list):
        for idx, row in enumerate(rows, 1):
            if isinstance(row, dict):
                frame_id = int(row.get("frame_id") or idx)
                caption = _clean(row.get("caption") or row.get("text") or row.get("prompt"))
            else:
                frame_id = idx
                caption = _clean(row)
            if caption:
                out[frame_id] = caption
    return out


def load_baseline_frames(out_dir: Path) -> List[FrameRecord]:
    result_path = _baseline_result_path(out_dir)
    if result_path is None:
        return []
    result = _read_json(result_path, {}) or {}
    input_captions = _captions_from_input(result.get("input"), out_dir)
    prompt_map = {
        int(row.get("frame_id") or idx): _clean(row.get("prompt"))
        for idx, row in enumerate(result.get("frame_prompts") or [], 1)
        if isinstance(row, dict)
    }
    frames: List[FrameRecord] = []
    for idx, row in enumerate(result.get("candidates") or [], 1):
        if not isinstance(row, dict):
            continue
        frame_id = int(row.get("frame_id") or idx)
        image_path = _resolve_path(row.get("image_path"), out_dir)
        if image_path is None:
            continue
        prompt = _clean(row.get("prompt") or prompt_map.get(frame_id))
        caption = _clean(input_captions.get(frame_id) or prompt_map.get(frame_id) or prompt)
        frames.append(FrameRecord(frame_id=frame_id, image_path=image_path, caption=caption, prompt=prompt))
    return frames


def load_fake_images(out_dir: Path, scope: str) -> List[Path]:
    if scope == "selected":
        return [x.image_path for x in load_selected_frames(out_dir)]
    if scope == "candidates":
        return _image_paths_in_dir(out_dir / "frames") + _image_paths_in_dir(out_dir / "ending_candidates")
    raise ValueError(f"Unknown fake scope: {scope}")


def discover_reference_image(out_dir: Path, explicit: str | None = None) -> Optional[Path]:
    if explicit:
        return _resolve_path(explicit, out_dir)
    seed = _read_json(out_dir / "seed.json", {}) or {}
    manifest = _read_json(out_dir / "output_manifest.json", {}) or {}
    keys = [
        "source_image_path",
        "image_path",
        "input_image",
        "reference_image",
        "canonical_reference_sheet_path",
    ]
    candidates: List[Any] = []
    baseline_result = _read_json(_baseline_result_path(out_dir), {}) if _baseline_result_path(out_dir) else {}
    baseline_input = {}
    if isinstance(baseline_result, dict) and baseline_result.get("input"):
        if isinstance(baseline_result.get("input"), dict):
            baseline_input = baseline_result.get("input") or {}
        else:
            input_path = _resolve_path(baseline_result.get("input"), out_dir)
            if input_path:
                baseline_input = _read_json(input_path, {}) or {}
    for data in [seed, seed.get("raw_input") if isinstance(seed, dict) else {}, manifest, baseline_result, baseline_input]:
        if not isinstance(data, dict):
            continue
        for key in keys:
            candidates.append(data.get(key))
        refs = data.get("protagonist_reference_paths") or []
        if isinstance(refs, list):
            candidates.extend(refs)
    for cand in candidates:
        p = _resolve_path(cand, out_dir)
        if p and p.suffix.lower() in IMAGE_EXTS:
            return p
    return None


class ClipScorer:
    def __init__(self, model_id: str, device: str, local_files_only: bool = False):
        import torch
        from transformers import CLIPModel, CLIPProcessor

        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.torch = torch
        self.device = device
        self.processor = CLIPProcessor.from_pretrained(model_id, local_files_only=local_files_only)
        self.model = CLIPModel.from_pretrained(model_id, local_files_only=local_files_only).to(device).eval()

    def _feature_tensor(self, output):
        if hasattr(output, "pooler_output"):
            return output.pooler_output
        if hasattr(output, "image_embeds"):
            return output.image_embeds
        if hasattr(output, "text_embeds"):
            return output.text_embeds
        if isinstance(output, (tuple, list)):
            if len(output) > 1:
                return output[1]
            return output[0]
        return output

    def _open_images(self, paths: Iterable[Path]) -> List[Image.Image]:
        return [Image.open(p).convert("RGB") for p in paths]

    def image_features(self, paths: List[Path], batch_size: int = 16):
        feats = []
        with self.torch.no_grad():
            for i in range(0, len(paths), batch_size):
                images = self._open_images(paths[i : i + batch_size])
                inputs = self.processor(images=images, return_tensors="pt")
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
                f = self._feature_tensor(self.model.get_image_features(**inputs))
                f = f / f.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                feats.append(f.detach().cpu())
        return self.torch.cat(feats, dim=0)

    def text_features(self, texts: List[str], batch_size: int = 16):
        feats = []
        with self.torch.no_grad():
            for i in range(0, len(texts), batch_size):
                inputs = self.processor(text=texts[i : i + batch_size], return_tensors="pt", padding=True, truncation=True)
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
                f = self._feature_tensor(self.model.get_text_features(**inputs))
                f = f / f.norm(dim=-1, keepdim=True).clamp_min(1e-12)
                feats.append(f.detach().cpu())
        return self.torch.cat(feats, dim=0)


def compute_clip_metrics(
    frames: List[FrameRecord],
    reference_image: Optional[Path],
    model_id: str,
    device: str,
    local_files_only: bool,
) -> Dict[str, Any]:
    scorer = ClipScorer(model_id=model_id, device=device, local_files_only=local_files_only)
    image_paths = [x.image_path for x in frames]
    captions = [x.caption for x in frames]
    image_f = scorer.image_features(image_paths)
    text_f = scorer.text_features(captions)
    clip_t = (image_f * text_f).sum(dim=-1).numpy().astype(float)

    frame_rows: List[Dict[str, Any]] = []
    for rec, score in zip(frames, clip_t):
        frame_rows.append({
            "frame_id": rec.frame_id,
            "image_path": str(rec.image_path),
            "caption": rec.caption,
            "clip_t": float(score),
        })

    result: Dict[str, Any] = {
        "model_id": model_id,
        "device": scorer.device,
        "clip_t_mean": float(np.mean(clip_t)),
        "clip_t_std": float(np.std(clip_t)),
        "frames": frame_rows,
    }

    if reference_image:
        ref_f = scorer.image_features([reference_image])[0]
        clip_i = (image_f * ref_f).sum(dim=-1).numpy().astype(float)
        result.update({
            "reference_image": str(reference_image),
            "clip_i_mean": float(np.mean(clip_i)),
            "clip_i_std": float(np.std(clip_i)),
        })
        for row, score in zip(frame_rows, clip_i):
            row["clip_i"] = float(score)
    else:
        result["clip_i_skipped"] = "No reference image was found. Pass --reference-image to compute CLIP-I."
    return result


def _sqrtm_product(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    prod = a.dot(b)
    vals, vecs = np.linalg.eig(prod)
    vals = np.where(vals.real < 0, 0, vals.real)
    inv_vecs = np.linalg.pinv(vecs)
    mat = vecs.dot(np.diag(np.sqrt(vals))).dot(inv_vecs)
    return np.real(mat)


def _frechet_distance(mu1: np.ndarray, sigma1: np.ndarray, mu2: np.ndarray, sigma2: np.ndarray) -> float:
    eps = 1e-6
    mu1 = np.atleast_1d(mu1)
    mu2 = np.atleast_1d(mu2)
    sigma1 = np.atleast_2d(sigma1) + np.eye(sigma1.shape[0]) * eps
    sigma2 = np.atleast_2d(sigma2) + np.eye(sigma2.shape[0]) * eps
    diff = mu1 - mu2
    covmean = _sqrtm_product(sigma1, sigma2)
    fid = diff.dot(diff) + np.trace(sigma1 + sigma2 - 2.0 * covmean)
    return float(np.real(fid))


def _inception_features(image_paths: List[Path], device: str, batch_size: int = 16) -> np.ndarray:
    import torch
    import torch.nn as nn
    from torchvision import models, transforms

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    weights = models.Inception_V3_Weights.DEFAULT
    model = models.inception_v3(weights=weights, aux_logits=True)
    model.fc = nn.Identity()
    model.to(device).eval()
    preprocess = transforms.Compose([
        transforms.Resize((299, 299)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    feats = []
    with torch.no_grad():
        for i in range(0, len(image_paths), batch_size):
            batch = []
            for p in image_paths[i : i + batch_size]:
                batch.append(preprocess(Image.open(p).convert("RGB")))
            x = torch.stack(batch, dim=0).to(device)
            y = model(x)
            if isinstance(y, tuple):
                y = y[0]
            feats.append(y.detach().cpu().numpy())
    return np.concatenate(feats, axis=0)


def compute_fid(real_dir: Optional[Path], fake_paths: List[Path], device: str, batch_size: int) -> Dict[str, Any]:
    if real_dir is None:
        return {"skipped": "FID requires --real-dir containing real/reference dataset images."}
    real_paths = _image_paths_in_dir(real_dir)
    if not real_paths:
        return {"skipped": f"No images found in real dir: {real_dir}"}
    if len(fake_paths) < 2 or len(real_paths) < 2:
        return {"skipped": "FID requires at least two real images and two fake images."}
    real_feats = _inception_features(real_paths, device=device, batch_size=batch_size)
    fake_feats = _inception_features(fake_paths, device=device, batch_size=batch_size)
    mu_real, sigma_real = real_feats.mean(axis=0), np.cov(real_feats, rowvar=False)
    mu_fake, sigma_fake = fake_feats.mean(axis=0), np.cov(fake_feats, rowvar=False)
    score = _frechet_distance(mu_real, sigma_real, mu_fake, sigma_fake)
    return {
        "fid": score,
        "real_dir": str(real_dir),
        "num_real": len(real_paths),
        "num_fake": len(fake_paths),
        "feature_backend": "torchvision_inception_v3_pool3",
        "warning": "FID is statistically unstable with very small image counts; use a dataset-scale real/fake set for paper reporting.",
    }


def _data_url(image_path: Path) -> str:
    mime = mimetypes.guess_type(str(image_path))[0] or "image/png"
    raw = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{raw}"


def _extract_json_object(text: str) -> Dict[str, Any]:
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not m:
        raise ValueError(f"No JSON object found in response: {text[:200]}")
    return json.loads(m.group(0))


def _openai_client():
    from openai import OpenAI

    kwargs: Dict[str, Any] = {}
    if os.environ.get("OPENAI_BASE_URL"):
        kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]
    return OpenAI(**kwargs)


def _tifa_questions(client, model: str, caption: str, max_questions: int) -> List[Dict[str, str]]:
    prompt = f"""
Create TIFA-style binary visual questions from the caption.
Return JSON only: {{"questions":[{{"question":"...", "answer":"yes"}}]}}
Rules:
- Use only facts that should be visible in the image.
- Cover protagonist, main action, important object, location/background, and visible emotion when possible.
- Do not ask about invisible internal thoughts.
- Expected answers should be "yes".
- Make at most {max_questions} questions.
Caption: {caption}
""".strip()
    resp = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
        response_format={"type": "json_object"},
    )
    data = _extract_json_object(resp.choices[0].message.content or "{}")
    questions = data.get("questions") or []
    out: List[Dict[str, str]] = []
    for q in questions[:max_questions]:
        if isinstance(q, dict) and _clean(q.get("question")):
            out.append({"question": _clean(q.get("question")), "answer": _clean(q.get("answer") or "yes").lower()})
    return out


def _tifa_answer_image(client, model: str, image_path: Path, questions: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    prompt = f"""
Answer these image questions with yes/no only.
Return JSON only: {{"answers":[{{"answer":"yes", "confidence":0.0, "reason":"short"}}]}}
Questions:
{json.dumps([q["question"] for q in questions], ensure_ascii=False)}
""".strip()
    resp = client.chat.completions.create(
        model=model,
        messages=[{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": _data_url(image_path)}},
            ],
        }],
        temperature=0,
        response_format={"type": "json_object"},
    )
    data = _extract_json_object(resp.choices[0].message.content or "{}")
    answers = data.get("answers") or []
    out: List[Dict[str, Any]] = []
    for idx, q in enumerate(questions):
        ans = answers[idx] if idx < len(answers) and isinstance(answers[idx], dict) else {}
        answer = _clean(ans.get("answer")).lower()
        if answer not in {"yes", "no"}:
            answer = "yes" if answer.startswith("y") else "no"
        out.append({
            "question": q["question"],
            "expected": q.get("answer", "yes"),
            "answer": answer,
            "confidence": ans.get("confidence"),
            "reason": _clean(ans.get("reason")),
            "correct": answer == q.get("answer", "yes"),
        })
    return out


def compute_tifa_style(frames: List[FrameRecord], text_model: str, vlm_model: str, max_questions: int) -> Dict[str, Any]:
    if not os.environ.get("OPENAI_API_KEY"):
        return {"skipped": "OPENAI_API_KEY is not set. Set it to compute VLM-based TIFA-style score."}
    client = _openai_client()
    frame_rows: List[Dict[str, Any]] = []
    scores: List[float] = []
    for rec in frames:
        questions = _tifa_questions(client, text_model, rec.caption, max_questions)
        answers = _tifa_answer_image(client, vlm_model, rec.image_path, questions) if questions else []
        score = float(sum(1 for a in answers if a.get("correct")) / max(1, len(answers)))
        scores.append(score)
        frame_rows.append({
            "frame_id": rec.frame_id,
            "image_path": str(rec.image_path),
            "caption": rec.caption,
            "score": score,
            "questions": answers,
        })
    return {
        "method": "vlm_qa_tifa_style",
        "text_model": text_model,
        "vlm_model": vlm_model,
        "max_questions_per_frame": max_questions,
        "tifa_mean": float(np.mean(scores)) if scores else None,
        "tifa_std": float(np.std(scores)) if scores else None,
        "frames": frame_rows,
        "note": "This is a TIFA-style VQA implementation using the configured VLM, not the original TIFA package.",
    }


def _markdown_report(report: Dict[str, Any]) -> str:
    lines = [
        "# Output Metric Report",
        "",
        f"- Output: `{report['output_dir']}`",
        f"- Fake scope: `{report['fake_scope']}`",
        f"- Selected frames: `{report['num_selected_frames']}`",
        "",
        "## Summary",
        "",
    ]
    clip = report.get("clip", {})
    if "error" in clip:
        lines.append(f"- CLIP: skipped/error: {clip['error']}")
    else:
        if clip.get("clip_t_mean") is not None:
            lines.append(f"- CLIP-T mean: `{clip['clip_t_mean']:.4f}`")
        if clip.get("clip_i_mean") is not None:
            lines.append(f"- CLIP-I mean: `{clip['clip_i_mean']:.4f}`")
        elif clip.get("clip_i_skipped"):
            lines.append(f"- CLIP-I: skipped ({clip['clip_i_skipped']})")
    fid = report.get("fid", {})
    if fid.get("fid") is not None:
        lines.append(f"- FID: `{fid['fid']:.4f}`")
    elif fid.get("skipped"):
        lines.append(f"- FID: skipped ({fid['skipped']})")
    tifa = report.get("tifa", {})
    if tifa.get("tifa_mean") is not None:
        lines.append(f"- TIFA-style mean: `{tifa['tifa_mean']:.4f}`")
    elif tifa.get("skipped"):
        lines.append(f"- TIFA-style: skipped ({tifa['skipped']})")
    elif tifa.get("error"):
        lines.append(f"- TIFA-style: error ({tifa['error']})")
    lines += ["", "## Per Frame", ""]
    clip_frames = {row["frame_id"]: row for row in clip.get("frames", []) if isinstance(row, dict)}
    tifa_frames = {row["frame_id"]: row for row in tifa.get("frames", []) if isinstance(row, dict)}
    for rec in report.get("frames", []):
        fid = rec["frame_id"]
        cf = clip_frames.get(fid, {})
        tf = tifa_frames.get(fid, {})
        parts = [f"- Frame {fid}: `{Path(rec['image_path']).name}`"]
        if "clip_t" in cf:
            parts.append(f"CLIP-T `{cf['clip_t']:.4f}`")
        if "clip_i" in cf:
            parts.append(f"CLIP-I `{cf['clip_i']:.4f}`")
        if "score" in tf:
            parts.append(f"TIFA `{tf['score']:.4f}`")
        lines.append("; ".join(parts))
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate DCEE-CausalVerse output folders with FID, CLIP-I, CLIP-T, and TIFA-style VQA.")
    parser.add_argument("--output", required=True, help="Output folder name under outputs/ or an explicit path.")
    parser.add_argument("--outputs-root", default="outputs")
    parser.add_argument("--reference-image", default=None, help="Original/reference image for CLIP-I. If omitted, the script tries to discover it from seed metadata.")
    parser.add_argument("--real-dir", default=None, help="Real image dataset folder for standard FID.")
    parser.add_argument("--fake-scope", choices=["selected", "candidates"], default="selected", help="Use final selected images or all candidate images as fake set for FID.")
    parser.add_argument("--clip-model", default="openai/clip-vit-base-patch32")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--local-files-only", action="store_true", help="Do not download Hugging Face/torchvision model weights.")
    parser.add_argument("--no-clip", action="store_true")
    parser.add_argument("--no-fid", action="store_true")
    parser.add_argument("--no-tifa", action="store_true")
    parser.add_argument("--tifa-text-model", default=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"))
    parser.add_argument("--tifa-vlm-model", default=os.environ.get("OPENAI_VLM_MODEL", os.environ.get("OPENAI_MODEL", "gpt-4o-mini")))
    parser.add_argument("--tifa-questions", type=int, default=5)
    parser.add_argument("--report-name", default="metric_report")
    args = parser.parse_args()

    out_dir = resolve_output_dir(args.output, args.outputs_root)
    frames = load_selected_frames(out_dir)
    fake_paths = load_fake_images(out_dir, args.fake_scope)
    reference = discover_reference_image(out_dir, args.reference_image)
    real_dir = _resolve_path(args.real_dir, Path.cwd()) if args.real_dir else None

    report: Dict[str, Any] = {
        "output_dir": str(out_dir),
        "fake_scope": args.fake_scope,
        "num_selected_frames": len(frames),
        "num_fake_images": len(fake_paths),
        "reference_image": str(reference) if reference else None,
        "real_dir": str(real_dir) if real_dir else None,
        "frames": [{"frame_id": f.frame_id, "image_path": str(f.image_path), "caption": f.caption, "prompt": f.prompt} for f in frames],
    }

    if args.no_clip:
        report["clip"] = {"skipped": "--no-clip was set."}
    else:
        try:
            report["clip"] = compute_clip_metrics(frames, reference, args.clip_model, args.device, args.local_files_only)
        except Exception as e:
            report["clip"] = {"error": f"{type(e).__name__}: {e}"}

    if args.no_fid:
        report["fid"] = {"skipped": "--no-fid was set."}
    else:
        try:
            report["fid"] = compute_fid(real_dir, fake_paths, args.device, args.batch_size)
        except Exception as e:
            report["fid"] = {"error": f"{type(e).__name__}: {e}"}

    if args.no_tifa:
        report["tifa"] = {"skipped": "--no-tifa was set."}
    else:
        try:
            report["tifa"] = compute_tifa_style(frames, args.tifa_text_model, args.tifa_vlm_model, args.tifa_questions)
        except Exception as e:
            report["tifa"] = {"error": f"{type(e).__name__}: {e}"}

    json_path = out_dir / f"{args.report_name}.json"
    md_path = out_dir / f"{args.report_name}.md"
    _write_json(json_path, report)
    md_path.write_text(_markdown_report(report), encoding="utf-8")
    print(json.dumps({
        "output_dir": str(out_dir),
        "report_json": str(json_path),
        "report_md": str(md_path),
        "clip_t_mean": report.get("clip", {}).get("clip_t_mean"),
        "clip_i_mean": report.get("clip", {}).get("clip_i_mean"),
        "fid": report.get("fid", {}).get("fid"),
        "tifa_mean": report.get("tifa", {}).get("tifa_mean"),
        "skipped": {
            "clip_i": report.get("clip", {}).get("clip_i_skipped"),
            "fid": report.get("fid", {}).get("skipped"),
            "tifa": report.get("tifa", {}).get("skipped"),
        },
        "errors": {
            "clip": report.get("clip", {}).get("error"),
            "fid": report.get("fid", {}).get("error"),
            "tifa": report.get("tifa", {}).get("error"),
        },
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
