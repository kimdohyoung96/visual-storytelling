from __future__ import annotations

from typing import Any, Dict

from .butterfly_adapter import ButterflyController
from .evaluator import DCEQAEvaluator
from .image_understanding import ImageUnderstandingModule
from .llm import build_llm, build_vlm
from .planner import DCEPlanner
from .pipeline_crossattn_butterfly import CrossAttentionButterflyDCEViStoryPipeline
from .prompts import NEGATIVE_PROMPT, QUALITY_SUFFIX
from .sdxl_cross_attention_generator_CQ2 import SDXLButterflyCrossAttentionGeneratorCQ2


class CrossAttentionButterflyDCEViStoryPipelineCQ2(CrossAttentionButterflyDCEViStoryPipeline):
    """CQ2 pipeline: V63.1 DCEE flow with style-locked cartoon-quality SDXL prompts."""

    def __init__(self, cfg: Dict[str, Any]):
        self.cfg = cfg
        self.llm = build_llm(cfg.get("llm", {}))
        self.vlm = build_vlm(cfg.get("vlm", {}))

        llm_cfg = cfg.get("llm", {})
        self.planner = DCEPlanner(
            self.llm,
            temperature=float(llm_cfg.get("temperature", 0.35)),
            max_tokens=int(llm_cfg.get("max_tokens", 1600)),
        )

        iu_cfg = cfg.get("image_understanding", {})
        self.image_understanding = ImageUnderstandingModule(
            iu_cfg.get("provider", "llm_caption"),
            self.llm,
            iu_cfg.get("caption_model", "Salesforce/blip-image-captioning-base"),
        )

        ev_cfg = cfg.get("evaluation", {})
        self.evaluator = DCEQAEvaluator(
            self.llm,
            self.vlm,
            use_vlm=bool(ev_cfg.get("use_vlm", False)),
            save_contact_sheet=bool(ev_cfg.get("save_contact_sheet", True)),
        )

        b_cfg = cfg.get("butterfly", {})
        self.controller = ButterflyController(
            b_cfg.get("quality_suffix", QUALITY_SUFFIX),
            b_cfg.get("negative_prompt", NEGATIVE_PROMPT),
            int(b_cfg.get("num_hypotheses", 3)),
        )

        img_cfg = cfg.get("image_generator", {})
        ad_cfg = cfg.get("cross_attention_adapters", {})
        self.image_generator = SDXLButterflyCrossAttentionGeneratorCQ2(
            model_id=img_cfg.get("model_id", "stabilityai/stable-diffusion-xl-base-1.0"),
            device=img_cfg.get("device", "cuda"),
            width=int(img_cfg.get("width", 1024)),
            height=int(img_cfg.get("height", 1024)),
            num_inference_steps=int(img_cfg.get("num_inference_steps", 36)),
            guidance_scale=float(img_cfg.get("guidance_scale", 7.5)),
            seed=int(img_cfg.get("seed", 42)),
            adapter_ckpt=ad_cfg.get("adapter_ckpt"),
            enable_cpu_offload=bool(img_cfg.get("enable_cpu_offload", False)),
            character_tokens=int(ad_cfg.get("character_tokens", 8)),
            world_tokens=int(ad_cfg.get("world_tokens", 8)),
            emotion_tokens=int(ad_cfg.get("emotion_tokens", 8)),
            event_tokens=int(ad_cfg.get("event_tokens", 8)),
            evidence_tokens=int(ad_cfg.get("evidence_tokens", 8)),
            use_refiner=bool(img_cfg.get("use_refiner", False)),
            refiner_model_id=img_cfg.get("refiner_model_id", "stabilityai/stable-diffusion-xl-refiner-1.0"),
            refiner_strength=float(img_cfg.get("refiner_strength", 0.80)),
            aesthetic_score=float(img_cfg.get("aesthetic_score", 6.0)),
            negative_aesthetic_score=float(img_cfg.get("negative_aesthetic_score", 2.5)),
            quality_model_preset=img_cfg.get("quality_model_preset", "sdxl_base"),
            use_ip_adapter=bool(img_cfg.get("use_ip_adapter", False)),
            ip_adapter_scale=float(img_cfg.get("ip_adapter_scale", 0.0)),
            canonical_reference_sheet_path=img_cfg.get("canonical_reference_sheet_path", ""),
            identity_backend_priority=img_cfg.get("identity_backend_priority", ["text"]),
            use_instantid=bool(img_cfg.get("use_instantid", False)),
            instantid_adapter_path=img_cfg.get("instantid_adapter_path", ""),
            instantid_controlnet_path=img_cfg.get("instantid_controlnet_path", ""),
            use_photomaker=bool(img_cfg.get("use_photomaker", False)),
            photomaker_adapter_path=img_cfg.get("photomaker_adapter_path", ""),
            use_character_lora=bool(img_cfg.get("use_character_lora", False)),
            character_lora_path=img_cfg.get("character_lora_path", ""),
            character_lora_scale=float(img_cfg.get("character_lora_scale", 0.85)),
            use_subject_scene_fusion=bool(img_cfg.get("use_subject_scene_fusion", False)),
            subject_scene_fusion_scale=float(img_cfg.get("subject_scene_fusion_scale", 0.72)),
            subject_scene_fusion_first_n=int(img_cfg.get("subject_scene_fusion_first_n", 0)),
            consistent_identity_seed_across_frames=bool(img_cfg.get("consistent_identity_seed_across_frames", True)),
            use_previous_frame_img2img=False,
        )
