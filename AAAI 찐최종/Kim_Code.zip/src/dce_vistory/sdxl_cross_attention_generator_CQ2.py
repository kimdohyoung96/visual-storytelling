from __future__ import annotations

import re
from typing import Any, Dict, List

from .sdxl_cross_attention_generator import (
    SDXLButterflyCrossAttentionGenerator,
    _clean,
    _clip_words,
    _join_unique,
    _resolve_protagonist_anchor,
    _simple_sentence,
)


class SDXLButterflyCrossAttentionGeneratorCQ2(SDXLButterflyCrossAttentionGenerator):
    """CQ2: style-locked high-quality cartoon/storybook visual compiler.

    This branch keeps the V63.1 DCEE pipeline and text-anchor identity setup, but
    packs style, identity, and story grounding into the first prompt segments so
    character design and full-color cartoon quality survive the CLIP token budget.
    """

    def _cq_quality_phrase(self, meta: Dict[str, Any]) -> str:
        return _clean(meta.get("cq_quality_prompt", "")) or (
            "premium full-color 2D storybook comic, crisp clean line art, polished rich color"
        )

    def _cq_style_lock(self, meta: Dict[str, Any]) -> str:
        return _clean(meta.get("cq_style_lock", "")) or (
            "same cartoon style, same character design, same body proportions"
        )

    def _cq_negative_phrase(self, meta: Dict[str, Any]) -> str:
        return _clean(meta.get("cq_negative_prompt", "")) or (
            "photorealistic, live action, realistic animal photo, 3d render, toy, sticker, grayscale, monochrome"
        )

    def _build_compiled_visual_prompt_pair(self, spec, meta: Dict[str, Any], mode: str):
        plan = self._render_plan_from_meta(meta) if bool(meta.get("use_llm_frame_prompt", True)) else {}
        identity_src = _clean(getattr(spec, "subject_identity", "")) or _resolve_protagonist_anchor(spec)
        identity_clauses = [c.strip() for c in re.split(r"[;]+", identity_src) if c.strip()]
        identity = _clip_words("; ".join(identity_clauses[:3]) or _resolve_protagonist_anchor(spec), 8)
        action = self._compiled_action_phrase(spec, plan)
        obj = self._compiled_object_phrase(spec, plan)
        scene = self._compiled_scene_phrase(spec, plan)
        emotion = self._compiled_emotion_phrase(spec, plan)
        variant = _clean(meta.get("sentence_lock_variant") or meta.get("variant_focus") or mode)
        protagonist = _clean(meta.get("json_protagonist_lock", "") or getattr(spec, "protagonist", "") or "protagonist")
        if "visible_signature_items_lock" in meta:
            signature_source = meta.get("visible_signature_items_lock", []) or []
        else:
            signature_source = meta.get("json_signature_items_lock", []) or getattr(spec, "required_objects", []) or []
        signature_items = _join_unique(signature_source, limit=3, per_item_words=4)
        age_body_lock = _clip_words(self._compiled_age_body_lock(spec, protagonist, identity), 7)
        quality = _simple_sentence(self._cq_quality_phrase(meta), 10)
        style_lock = _simple_sentence(self._cq_style_lock(meta), 8)
        action_short = _clip_words(action, 7)
        object_short = _clip_words(obj, 8)
        emotion_short = _clip_words(emotion, 6)
        scene_short = _clip_words(scene, 6)
        story_short = _simple_sentence(getattr(spec, "story_sentence", ""), 12)

        # Keep the first prompt short: subject/action/object/emotion/place must
        # survive token fitting before style details.
        prompt_segments: List[str] = [
            f"{quality}; exactly one {protagonist}; {identity}; {age_body_lock}",
            f"current story: {action_short}; {object_short}; {emotion_short}; {scene_short}",
            f"style lock: {style_lock}",
            f"sentence: {story_short}" if story_short else "",
        ]
        prompt2_segments: List[str] = [
            f"full-color consistent 2D storybook comic; {style_lock}",
            f"must show: {protagonist}; {object_short}; {action_short}",
            f"emotion: {emotion_short}; place: {scene_short}",
            "polished color, clean contours, readable face, detailed story background",
        ]
        if variant == "signature":
            prompt_segments.insert(1, f"required object visible: {object_short}")
        elif variant in {"emotion", "emotion_face"}:
            prompt_segments.insert(2, f"visible expression: {emotion_short}")
        elif variant == "identity":
            prompt_segments.insert(1, f"same recurring character: {identity}; {age_body_lock}")
        elif variant == "scene":
            prompt_segments.insert(2, f"detailed story background: {scene_short}")

        negative_segments = [
            "different protagonist, wrong species, wrong color, wrong age, unrelated animal, unrelated person",
            "missing protagonist, hidden protagonist, cropped body, tiny subject",
            "missing required object, wrong object, wrong action, wrong background, missing emotion",
            "duplicate protagonist, extra character, extra animal, style shift between frames",
            "black and white, grayscale, monochrome, uncolored sketch, flat empty background",
            "text, watermark, logo, random letters, printed label, blurry, deformed, low detail",
            self._cq_negative_phrase(meta),
            _clean(getattr(spec, "negative", "")),
        ]

        tok1 = getattr(self.pipe, "tokenizer", None)
        tok2 = getattr(self.pipe, "tokenizer_2", None) or tok1
        prompt, fit1 = self._fit_segments(tok1, prompt_segments, reserve=3) if tok1 is not None else (". ".join([s for s in prompt_segments if s]), {})
        prompt_2, fit2 = self._fit_segments(tok2, prompt2_segments, reserve=3) if tok2 is not None else (". ".join([s for s in prompt2_segments if s]), {})
        negative_prompt, negfit = self._fit_segments(tok1 or tok2, negative_segments, reserve=3) if (tok1 or tok2) is not None else (", ".join([s for s in negative_segments if s]), {})
        prompt = self._hard_trim_to_token_limit(tok1, prompt, reserve=3)
        prompt_2 = self._hard_trim_to_token_limit(tok2, prompt_2, reserve=3)
        negative_prompt = self._hard_trim_to_token_limit(tok1 or tok2, negative_prompt, reserve=3)
        audit = self._token_report(prompt, prompt_2, negative_prompt)
        audit.update({
            "prompt_strategy": "CQ2_style_locked_cartoon_story_first",
            "compiled_identity": identity,
            "compiled_action": action,
            "compiled_object": obj,
            "compiled_scene": scene,
            "compiled_emotion": emotion,
            "compiled_age_body_lock": age_body_lock,
            "sentence_lock_variant": variant,
            "cq_quality": quality,
            "cq_style_lock": style_lock,
            "prompt_fit_tokenizer_1": fit1,
            "prompt_fit_tokenizer_2": fit2,
            "negative_fit": negfit,
        })
        return prompt, prompt_2, negative_prompt, audit

    def _build_prompt_pair(self, spec, meta: Dict[str, Any], mode: str):
        return self._build_compiled_visual_prompt_pair(spec, meta, mode)
