# DCEE-CausalVerse V54 — Input-Grounded Protagonist Lock Patch

## 왜 V53에서 토끼/너구리/기타 동물이 나왔는가
V53 실패 원인을 분석하면 다음과 같다.

1. **Prompt는 강했지만, protagonist species를 강제로 reject하는 hard gate가 부족했다.**
   - 잘못된 후보(토끼, 너구리, 여우)가 생성되어도 caption/rerank만으로 완전히 제거되지 못했다.

2. **Text-only 생성 특성상 SDXL이 'cute forest animal' prior로 치우쳤다.**
   - 흰곰 대신 rabbit / raccoon / fox 같은 흔한 동화형 동물이 대체 주인공으로 나올 수 있었다.

3. **Input-grounded contract가 약했다.**
   - 입력의 `protagonist`, `signature_items`, `target_ending_emotion`, `text_prompt`가 모든 frame prompt에서 최상위 source-of-truth로 강제되지 않았다.

4. **DCEE step은 유지됐지만, species lock > sentence lock > object/scene lock 순서의 우선순위가 명시적으로 강제되지 않았다.**

## V54 핵심 수정

### 1) Input-grounded protagonist contract 강화
- `sample.text_prompt`, `sample.protagonist`, `sample.signature_items`, `sample.target_ending_emotion`를 packet metadata에 직접 주입
- generator prompt 최상단에 **input story / input protagonist / signature item** 을 명시

### 2) Hard protagonist species lock 추가
- white bear story에서 **rabbit / raccoon / fox / squirrel / panda / brown bear / teddy bear / human** 이 나오면 강한 penalty
- `protagonist_species_score`와 `forbidden_species_penalty`를 evaluator에 추가
- threshold 미달 시 frame을 다시 생성

### 3) Identity-focused emergency retry 추가
- 일반 retry 이후에도 주인공 종(species)이 틀리면
  `variant_focus = identity` + `hard_protagonist_lock = True` 로 emergency regeneration 수행

### 4) Sentence-exact literal prompting 유지
- frame별 story sentence를 그대로 시각화하도록 `EXACT STORY MOMENT` 기반 literal prompt 강화
- honey jar / lake / forest / underbrush / emotion 등을 누락하지 않도록 유지

### 5) DCEE framework 유지
- 각 frame는 현재 DCEE step만 보여주도록 유지
- 이전/다음 frame을 건너뛰지 않도록 progression constraint 유지

## 실행
```bash
python run_v54.py \
  --config configs/config_v54_input_grounded_protagonist_lock.yaml \
  --input examples/white_bear_text_only_v54.json \
  --out outputs/DCEE_v54_white_bear_text_only
```

## 포함 파일
- `run_v54.py`
- `configs/config_v54_input_grounded_protagonist_lock.yaml`
- `examples/white_bear_text_only_v54.json`
- `src/dce_vistory/frame_director.py`
- `src/dce_vistory/sdxl_cross_attention_generator.py`
- `src/dce_vistory/evaluator.py`
- `src/dce_vistory/pipeline_crossattn_butterfly.py`
