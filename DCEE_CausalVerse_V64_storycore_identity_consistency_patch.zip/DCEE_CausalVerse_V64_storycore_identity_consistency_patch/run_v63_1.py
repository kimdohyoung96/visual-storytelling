from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from src.dce_vistory.pipeline_crossattn_butterfly import CrossAttentionButterflyDCEViStoryPipeline


def main():
    ap = argparse.ArgumentParser(description='Run DCEE-CausalVerse V63.1 signature coverage hotfix pipeline')
    ap.add_argument('--config', required=True)
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', '--out', dest='output', required=True)
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding='utf-8'))
    sample = json.loads(Path(args.input).read_text(encoding='utf-8'))
    sample.setdefault('image_path', '')
    sample.setdefault('protagonist_reference_paths', [])
    sample.setdefault('canonical_reference_sheet_path', '')

    pipe = CrossAttentionButterflyDCEViStoryPipeline(cfg)
    pipe.run(sample=sample, out_dir=Path(args.output))
    print(json.dumps({
        'output_dir': str(Path(args.output)),
        'final_story': str(Path(args.output) / 'final_story.md'),
        'storyboard': str(Path(args.output) / 'storyboard.json'),
        'evaluation': str(Path(args.output) / 'evaluation.json')
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
