# DCEE-CausalVerse V62.1 — pipe_cfg Hotfix

## Fixed error

V62 failed with:

```text
UnboundLocalError: cannot access local variable 'pipe_cfg' where it is not associated with a value
```

Cause:
`force_json_story_flow = _v62_should_force_json_story_flow(sample, pipe_cfg)` was called before `pipe_cfg` was assigned inside `run()`.

Fix:
`pipe_cfg`, `selection_cfg`, and `img_cfg` are now initialized before abstract/DCEE generation.

## Run

```bash
python run_v62_1.py \
  --config configs/config_v62_1_story_exact_selection_hotfix.yaml \
  --input examples/white_bear_text_only_v62_1.json \
  --out outputs/DCEE_v62_1_white_bear_text_only
```
