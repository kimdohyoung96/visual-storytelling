# DCEE-CausalVerse V56 — Anchor Identity + Story-Exact Patch

## V55에서 남아 있던 문제
- 일부 frame에서 **흰곰 색상**이 다시 흔들림
- frame별로 **성체/유년체**가 바뀜
- frame 1~6의 주인공 **형태, 크기, 실루엣**이 서로 달라짐
- 일부 frame은 story sentence 전체를 충분히 반영하지 못함

## V56 핵심 수정

### 1) Frame-1 anchor identity 고정
- frame 1에서 선택된 주인공 이미지를 **identity anchor image** 로 저장
- frame 2~6은 이 anchor를 가장 우선 reference로 사용
- 이전 frame보다 **frame 1 anchor를 최우선** 으로 사용해 drift를 줄임

### 2) Text-only 후속 frame에도 reference-fusion 사용
- V55는 text-only에서 주로 text-story 모드였음
- V56은 frame 2 이후 anchor가 생기면 **fusion / continuity / scene-first** 후보를 함께 생성
- subject-scene fusion을 text-only 후속 frame에도 허용해 주인공 일관성 강화

### 3) Shape / silhouette / age / color hard lock
- same muzzle shape, ear size, head-to-body ratio, body mass, limb thickness, silhouette
- white fur exact lock
- adult/cub age-stage lock
- hard protagonist shape lock 메타 플래그 추가

### 4) Candidate selection에서 identity/continuity 기준 강화
- `identity_consistency_threshold` 추가
- `reference_subject_similarity_threshold` 추가
- `continuity_threshold` 추가
- 후속 frame에서 위 점수가 낮으면 재생성

### 5) Sentence-complete story grounding 강화
- story/action/object/scene coverage threshold 상향
- honey / jar 등 핵심 단어 누락 시 감점 강화
- text-only candidate 수 증가

## 실행
```bash
python run_v56.py \
  --config configs/config_v56_anchor_identity_story.yaml \
  --input examples/white_bear_text_only_v56.json \
  --out outputs/DCEE_v56_white_bear_text_only
```
