# DCEE-CausalVerse V48: V46.2 Restore + Visual Storytelling Grounding

## Why V48
- Reverts the VAE handling back to the V46.2-style behavior (no forced `pipe.vae.to(torch.float32)` override).
- Preserves the more stable non-black-image generation path.
- Adds stronger literal visual storytelling constraints so the generated image follows the story sentence more directly.

## Main updates
1. **V46.2 VAE path restored**
   - Removes the risky forced VAE dtype override path introduced later.
   - Keeps the stable SDXL decode flow from V46.2.

2. **Stronger story-to-image grounding**
   - More explicit frame rules for:
     - forest search
     - dense underbrush interaction
     - lake arrival
     - jar discovery at the water edge
     - jar retrieval
     - savoring honey beside the lake
   - Adds clearer emotion-expression instructions.

3. **Continuity improvements**
   - In text-only mode, later frames receive continuity from:
     - first selected frame
     - previous selected frame
     - previous two selected frames metadata
   - Final frame gets a stronger identity-lock prompt.

4. **Harder penalties for wrong content**
   - Stronger evaluator penalties for:
     - wrong-color bear
     - extra animals / people
     - missing jar / lake / underbrush cues
     - wrong frame-state behavior
