# DCEE-CausalVerse V57 — JSON-Grounded White Bear Patch

## V56에서 남은 문제
- frame 1, 3, 6 등에서 주인공이 갈색 곰처럼 생성됨
- frame 1~6 사이에서 주인공의 얼굴/형태/크기/실루엣이 흔들림
- `white_bear_text_only_v56.json`의 `protagonist: white bear`, `signature_items: [honey jar]`가 generation 전반에 충분히 강제되지 않음

## V57 핵심 수정

### 1) JSON 입력을 source of truth로 승격
- `protagonist`와 `signature_items`를 canonicalize 후 pipeline 시작 시 강제 적용
- `seed.protagonist`, `seed.signature_items`, `seed.character_profiles`, `seed._story_bible` 모두 JSON 계약 기준으로 덮어씀
- `json_input_contract` 메타데이터를 모든 frame prompt에 전달

### 2) White bear / honey jar hard grounding
- protagonist가 bear+white이면 canonical protagonist를 `white bear`로 고정
- signature item이 honey 계열이면 canonical object를 `honey jar`로 고정
- prompt에 JSON HARD CONTRACT / HARD JSON PROTAGONIST LOCK / HARD JSON SIGNATURE LOCK 추가

### 3) Frame 1 강화
- frame 1 후보 수 확대 (`frame1_num_candidates`)
- frame 1 전용 stricter threshold 추가
  - species
  - white exact
  - color
  - age
  - object coverage
  - sentence completeness
- frame 1이 틀리면 이후 frame들이 따라 틀리므로 anchor frame을 더 엄격하게 선별

### 4) Cross-frame appearance continuity 강화
- frame 2~6은 frame 1 anchor + JSON protagonist 계약을 동시에 따름
- same silhouette / same relative size / same muzzle / same paw size 규칙 추가

### 5) Story sentence literal grounding 강화
- story action, object, scene, emotion, sentence completeness 기준 상향
- honey jar가 필요한 문장에서는 생략/대체를 강하게 감점

## 실행
```bash
python run_v57.py \
  --config configs/config_v57_json_grounded_whitebear.yaml \
  --input examples/white_bear_text_only_v57.json \
  --out outputs/DCEE_v57_white_bear_text_only
```
