# DCEE-CausalVerse V63.1 — Signature Coverage Hotfix

## Fixed error

V63 failed with:

```text
TypeError: unsupported operand type(s) for +: 'set' and 'list'
```

Cause:
`_phrase_variants(item)` returns a `set`, but V63 tried to concatenate it with a Python list.

Fix:
V63.1 converts the set to a list before extending it.

## Run

```bash
python run_v63_1.py \
  --config configs/config_v63_1_signature_emotion_storycore_hotfix.yaml \
  --input examples/white_bear_text_only_v63_1.json \
  --out outputs/DCEE_v63_1_white_bear_text_only
```
