# DCEE-CausalVerse V51.1 — sentence threshold hotfix

This patch fixes the V51 runtime error:

```text
NameError: name 'sentence_complete_threshold' is not defined
```

## Cause
V51 added `sentence_complete_score` and `protagonist_color_consistency` retry checks, but the corresponding threshold variables were not defined in `pipeline_crossattn_butterfly.py`.

## Fix
The pipeline now defines these thresholds in scope:

- `sentence_complete_threshold`
- `protagonist_color_threshold`
- `text_only_sentence_complete_threshold`
- `text_only_protagonist_color_threshold`

The code also reads threshold values from either `pipeline` or `selection` config sections.

## Run
```bash
python run_v51_1.py \
  --config configs/config_v51_1_sentence_threshold_hotfix.yaml \
  --input examples/white_bear_text_only_v51_1.json \
  --out outputs/DCEE_v51_1_white_bear_text_only
```
