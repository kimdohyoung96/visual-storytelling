# DCEE-CausalVerse V50 — safe VAE upcast patch + frame-distinct story grounding

## 핵심 수정
1. **upcast_vae deprecation 대응**
   - diffusers SDXL pipeline 인스턴스의 `upcast_vae()`를 로컬 safe patch로 교체했습니다.
   - `pipe.vae.to(torch.float32)`를 직접 반영하되, 생성 전에 전역 고정하지 않고 **decode 시점에만** float32로 올리도록 했습니다.
   - 따라서 V47에서 발생했던 black image 문제를 피하면서 FutureWarning 원인을 제거하도록 구성했습니다.

2. **프레임 중복 생성 방지**
   - 기존에는 identity consistency 옵션이 켜지면 프레임 간 seed가 사실상 재사용되어, 서로 다른 스토리 문장인데도 유사/동일 이미지가 반복될 수 있었습니다.
   - V50에서는 **frame id + story sentence + action + variant focus**를 반영한 `story_seed`를 사용합니다.
   - 덕분에 동일 주인공 정체성은 유지하면서도 프레임별 장면 차이는 커집니다.

3. **story 단어 반영 강화**
   - text-only candidate variant에 `emotion`, `color`를 추가했습니다.
   - object / scene / action뿐 아니라 감정 표현과 흰 곰 색상 유지까지 별도 후보로 평가합니다.

4. **recent-repeat penalty 추가**
   - 후보가 직전 프레임뿐 아니라 최근 선택 프레임들과도 너무 비슷하면 감점하도록 evaluator를 확장했습니다.

## 새 실행 파일
- `run_v50.py`
- `configs/config_v50_safe_vae_frame_distinct.yaml`
- `examples/white_bear_text_only_v50.json`

## 실행 예시
```bash
python run_v50.py   --config configs/config_v50_safe_vae_frame_distinct.yaml   --input examples/white_bear_text_only_v50.json   --out outputs/DCEE_v50_white_bear_text_only
```
