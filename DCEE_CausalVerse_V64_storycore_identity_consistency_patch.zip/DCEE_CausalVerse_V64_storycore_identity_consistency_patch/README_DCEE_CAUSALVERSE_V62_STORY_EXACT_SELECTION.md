# DCEE-CausalVerse V62 — Story-Exact Candidate Gate Patch

## Why V61.1 drifted away from the story
1. **Planner drift / fallback drift**: when strict DCEE JSON failed, the fallback could still produce a generic plan and story that weakened the original input contract.
2. **Prompt dilution**: the final image prompt was strong, but the chosen candidate was often not the one with the best action/object faithfulness.
3. **Selection bias**: reranking still allowed images with high identity/scene scores but poor action coverage to win.
4. **No hard candidate gate**: candidates that missed core sentence elements were not filtered aggressively enough.

## What V62 changes
- Adds `force_json_story_flow`: input JSON becomes the source of truth for abstract, DCEE plan, and per-frame story steps in text-only strict mode.
- Generates **input-grounded abstract** and **input-grounded DCEE plan**.
- Uses **precomputed story steps** directly when strict JSON story flow is enabled.
- Adds **candidate gate selection**: story/object/action/scene/sentence completeness and protagonist continuity are all checked before final selection.
- If the first ranking fails the gate, V62 runs rescue variants (`identity`, `object`, `scene`, `action`, `complete`) and selects the candidate with the best gate score.
- Strengthens literal rendering in the SDXL strict story prompt.

## Run
```bash
python run_v62.py \
  --config configs/config_v62_story_exact_selection.yaml \
  --input examples/white_bear_text_only_v62.json \
  --out outputs/DCEE_v62_white_bear_text_only
```
