# DCEE-CausalVerse V49.1 Word Threshold Hotfix

## Fixed error
V49 crashed with:

```text
NameError: name 'object_word_threshold' is not defined
```

## Cause
V49 added word-level verification metrics and retry conditions, but the retry branch referenced these variables before defining them in `pipeline_crossattn_butterfly.py`.

## Fix
Defined the following thresholds in the pipeline scope:
- `word_coverage_threshold`
- `action_word_threshold`
- `scene_word_threshold`
- `object_word_threshold`
- `emotion_word_threshold`
- `color_word_threshold`

Also added text-only stricter defaults:
- `text_only_word_coverage_threshold`
- `text_only_action_word_threshold`
- `text_only_scene_word_threshold`
- `text_only_object_word_threshold`
- `text_only_emotion_word_threshold`
- `text_only_color_word_threshold`

## Run
```bash
python run_v49_1.py   --config configs/config_v49_1_word_threshold_hotfix.yaml   --input examples/white_bear_text_only_v49_1.json   --out outputs/DCEE_v49_1_white_bear_text_only
```
