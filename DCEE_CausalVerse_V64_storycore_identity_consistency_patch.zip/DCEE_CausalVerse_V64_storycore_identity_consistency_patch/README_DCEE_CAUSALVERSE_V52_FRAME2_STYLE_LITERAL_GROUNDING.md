# DCEE-CausalVerse V52: Frame-2-style literal grounding

V52 targets the V51.1 failure pattern where only Frame 2 was acceptable and other frames drifted into fox / brown bear / teddy bear / human / missing honey-jar outputs.

## Key changes
1. **Frame-2-style primary prompt**
   - The first CLIP prompt now begins with a compact literal prompt containing:
     - one large adult white bear,
     - creamy white fur / black eyes / black nose,
     - exact action,
     - honey-jar object state,
     - scene,
     - emotion.
   - This prevents the important story words from being dropped after token trimming.

2. **Literal prompt builder**
   - Adds `literal_primary_prompt` to `FrameVisualSpec`.
   - The generator uses it as the first prompt segment for every frame.

3. **Honey-jar object-state lock**
   - Search / discovery / savor / lick stages now generate different object-state prompts:
     - missing honey jar as search target,
     - honey jar at water edge,
     - open honey jar with visible golden honey,
     - licking the honey jar.

4. **Evaluator bug fix**
   - V51.1 showed `story_word_coverage=1.0` even when captions did not mention the required story words.
   - V52 derives action/scene/object/emotion/color targets directly from `story_sentence` when the frame object lacks generated keyword fields.

5. **Hard rejection of wrong subject/object**
   - Stronger penalties for fox, squirrel, teddy bear, small animal, human/girl/boy, brown bear, and missing honey jar.

## Run
```bash
python run_v52.py \
  --config configs/config_v52_frame2_style_literal_grounding.yaml \
  --input examples/white_bear_text_only_v52.json \
  --out outputs/DCEE_v52_white_bear_text_only
```
