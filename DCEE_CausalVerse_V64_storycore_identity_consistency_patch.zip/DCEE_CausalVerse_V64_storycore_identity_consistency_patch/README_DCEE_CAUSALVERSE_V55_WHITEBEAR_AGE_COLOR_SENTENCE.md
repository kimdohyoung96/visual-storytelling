# DCEE-CausalVerse V55 — White-Bear Age/Color/Sentence Consistency Patch

## V54 대비 핵심 수정

V54는 species lock은 개선되었지만, 다음 문제가 남아 있었다.

1. frame 1~6 사이에 **흰곰의 색상(white fur)** 이 흔들림
2. frame마다 **성체 ↔ 유체(cub)** 가 바뀌며 나이 일관성이 무너짐
3. 일부 frame은 story sentence 전체를 반영하지 못하고 배경/행위/사물이 누락됨

## V55 수정 사항

### 1) White-bear exact lock 강화
- `protagonist_white_bear_exact_score` 추가
- white bear가 아닌 brown/orange/tan/golden/gray bear는 강하게 감점
- 후보 선택 및 retry에서 white bear exact threshold를 통과해야 함

### 2) Age-stage consistency 추가
- frame 1에서 선택된 결과의 caption을 기준으로 `anchor_age_stage` 추론
- 이후 모든 frame은 동일 age-stage를 유지
- `protagonist_age_consistency_score`, `protagonist_age_penalty` 추가
- adult로 시작하면 이후 frame도 adult, cub로 시작하면 이후 frame도 cub 유지

### 3) Prompt에 frame-1 identity contract 주입
- frame 1 caption을 이후 frame prompt에 넣어
  같은 얼굴, 같은 체형, 같은 흰 털, 같은 나이대로 유지
- `APPEARANCE CONTRACT`, `AGE STAGE LOCK`, `FUR COLOR LOCK` 추가

### 4) Story sentence completeness 강화
- 모든 frame에서 story sentence의 행동/표정/사물/배경을 동시에 만족하도록 threshold 강화
- text-only 후보 수 증가 및 retry 강화

## 실행
```bash
python run_v55.py \
  --config configs/config_v55_whitebear_age_color_sentence.yaml \
  --input examples/white_bear_text_only_v55.json \
  --out outputs/DCEE_v55_white_bear_text_only
```
