# DCEE-CausalVerse V61 — Story/Abstract/Caption Identity-Lock Patch

## Goal
V61 strengthens two failure points from V60:

1. frame image omitted parts of the story/caption
2. protagonist identity drifted across frames

## V61 core changes
- stronger JSON-grounded protagonist contract
- fixed white-bear identity lock:
  - exactly one recurring white bear
  - same adult/cub age stage across frames
  - creamy white fur across frames
  - same face/body proportions across frames
- stricter prompt branch inside `sdxl_cross_attention_generator.py`
- frame prompt generated only from:
  - generated story sentence
  - frame caption
  - story abstract
  - DCEE plan
  - input JSON contract
- stronger negative prompt against brown bear / rabbit / raccoon / species swap
- higher selection thresholds for sentence completeness, object coverage, scene coverage, and color coverage

## Run
```bash
python run_v61.py \
  --config configs/config_v61_story_caption_identity_lock.yaml \
  --input examples/white_bear_text_only_v61.json \
  --out outputs/DCEE_v61_white_bear_text_only
```
