# DCEE-CausalVerse V60 — Strict Story/Abstract/Caption-Only Frame Generation

## Goal
V60 prevents random/fallback frame generation.

Each frame image must be generated only from:

1. generated story sentence
2. story abstract
3. current frame caption
4. DCEE plan
5. input JSON contract

The generator should not use a generic animal/forest prior, fallback prompt, or unrelated visual imagination.

## Main changes
- Adds `v60_strict_story_frame_only` metadata to every frame packet.
- Forces all SDXL candidates into strict `text_story` mode.
- Disables subject-scene fusion/fallback modes for V60.
- Adds a strict V60 prompt branch inside `sdxl_cross_attention_generator.py`.
- The strict branch builds prompt only from:
  - `story_abstract`
  - `generated_story_context`
  - `current_frame_caption`
  - `current_story_sentence`
  - `dcee_plan_summary`
  - JSON protagonist/signature items
- Adds `disable_fallback_generation`, `force_text_story_only`, and `sentence_lock_only` controls.
- Strengthens story/caption/object coverage thresholds.

## Run
```bash
python run_v60.py \
  --config configs/config_v60_strict_story_frame_only.yaml \
  --input examples/white_bear_text_only_v60.json \
  --out outputs/DCEE_v60_white_bear_text_only
```
