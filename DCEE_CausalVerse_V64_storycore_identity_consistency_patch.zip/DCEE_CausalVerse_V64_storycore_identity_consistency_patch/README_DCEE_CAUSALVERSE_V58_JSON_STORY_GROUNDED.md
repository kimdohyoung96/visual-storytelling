# DCEE-CausalVerse V58 — JSON + Story Grounded White-Bear Patch

## What changed
- Fixes the V57 frame_director f-string syntax issue.
- Adds JSON-grounded story-step construction so the pipeline reads `protagonist`, `signature_items`, and optional `story_sentences` directly from the input JSON.
- Adds a deterministic fallback 6-frame white-bear/honey-jar story for the text-only white-bear sample when explicit frame sentences are not provided.
- Repairs each planner-produced story step with the JSON contract before converting it to a frame.
- Enforces a strict recurring protagonist contract on every frame: one adult white bear, creamy white fur, same face, same silhouette, same age stage.
- Strengthens the SDXL prompt builder with a V58 story lock so each frame must follow the exact current sentence while keeping the same protagonist identity.
- Saves the precomputed frame sentences to `json_grounded_story_steps.json` for debugging and verification.

## New files
- `run_v58.py`
- `configs/config_v58_json_story_grounded.yaml`
- `examples/white_bear_text_only_v58.json`

## Run
```bash
python run_v58.py \
  --config configs/config_v58_json_story_grounded.yaml \
  --input examples/white_bear_text_only_v58.json \
  --out outputs/DCEE_v58_white_bear_text_only
```
