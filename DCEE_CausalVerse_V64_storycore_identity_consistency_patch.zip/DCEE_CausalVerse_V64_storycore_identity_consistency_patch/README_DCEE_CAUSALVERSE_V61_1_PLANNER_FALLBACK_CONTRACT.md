# DCEE-CausalVerse V61.1 — Planner Fallback + FrameRenderContract Patch

## Fixed runtime error

The previous run failed at:

```text
planner.generate_dce_plan -> Strict LLM JSON generation failed
```

V61.1 catches that failure and creates a deterministic DCEE plan from the input JSON instead of crashing.

## Added safeguards

- Safe fallback for `generate_dce_plan`
- Safe fallback for `generate_emotion_arc`
- Safe fallback for per-frame `generate_story_step`
- Safe wrapper for `anchor_bank.build_from_seed_and_plan`
- Fixes the latent `dce_plan` scope issue in `_generate_llm_render_plan`

## Added V61.1 improvements

- Saves `canonical_protagonist_contract_v61_1.json`
- Saves `frame_render_contracts_v61_1.json`
- Adds a strict `FrameRenderContract` per frame:
  - story sentence
  - frame caption
  - abstract
  - DCEE plan summary
  - protagonist identity
  - must-show items
  - must-not-show items
  - object state
  - scene state
  - emotion/action
- SDXL prompt now explicitly reads the V61.1 frame contract.
- The protagonist contract is strengthened:
  - exactly one recurring white bear
  - creamy white fur
  - same face/body proportions
  - same age stage
  - no species swap

## Run

```bash
python run_v61_1.py \
  --config configs/config_v61_1_planner_fallback_contract.yaml \
  --input examples/white_bear_text_only_v61_1.json \
  --out outputs/DCEE_v61_1_white_bear_text_only
```
