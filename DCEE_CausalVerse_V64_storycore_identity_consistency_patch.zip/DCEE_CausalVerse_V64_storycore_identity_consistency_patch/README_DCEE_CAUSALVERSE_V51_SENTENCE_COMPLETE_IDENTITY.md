# DCEE-CausalVerse V51: sentence-complete + identity-consistent frame grounding

V51 builds on V50 and focuses on the exact failure mode you reported:
- each frame was only partially following the generated story sentence,
- the white bear's fur color and face drifted across frames,
- the honey jar was often omitted,
- several frames repeated similar content instead of depicting the exact current story moment.

## What changed
1. **Sentence-completeness contract**
   - For every frame, the code now extracts an explicit contract covering:
     - protagonist identity,
     - action,
     - emotion,
     - setting,
     - required objects,
     - object-state hint.
   - This contract is injected directly into the image prompt.

2. **Stronger white-bear identity lock**
   - The prompt now explicitly locks: creamy white fur, black eyes, black nose, rounded ears, stocky adult bear body.
   - A protagonist color consistency score is added during reranking.

3. **Honey-jar literal grounding**
   - If the story sentence mentions honey / jar, the frame now treats the honey jar as a central visible story object.
   - An object-state hint is generated automatically (search target / discovery / retrieval / savoring).

4. **Full-sentence retry loop**
   - A new `complete` retry mode is added.
   - If action/object/scene/emotion/color coverage is still weak, the pipeline performs another regeneration pass with a full-sentence emphasis.

5. **New ranking score**
   - `sentence_complete_score` aggregates action, object, scene, emotion, color, and critical noun coverage.
   - `missing_signature_object_penalty` penalizes frames that should show the honey jar but fail to mention it.

## Main files changed
- `src/dce_vistory/frame_director.py`
- `src/dce_vistory/sdxl_cross_attention_generator.py`
- `src/dce_vistory/evaluator.py`
- `src/dce_vistory/pipeline_crossattn_butterfly.py`
- `configs/config_v51_sentence_complete_identity.yaml`
- `run_v51.py`
- `examples/white_bear_text_only_v51.json`

## Recommended command
```bash
python run_v51.py   --config configs/config_v51_sentence_complete_identity.yaml   --input examples/white_bear_text_only_v51.json   --out outputs/DCEE_v51_white_bear_text_only
```
