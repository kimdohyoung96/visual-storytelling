# DCEE-CausalVerse V49: Word-Check + Story Verifier Grounding

## Core idea
V49 adds an explicit **story-word verification loop** for each frame.
Instead of only using general story alignment, it now:
1. extracts frame-level visual checklist terms from the story sentence,
2. injects those checklist terms into the image prompt,
3. captions each candidate image,
4. checks whether action / scene / object / emotion / color words are actually reflected,
5. retries generation with a stronger literal mode when coverage is low.

## Main additions
- **Word-level checklist extraction** from the story sentence
  - action words
  - scene/background words
  - object words
  - emotion/expression words
  - color/identity words
- **Prompt grounding strengthened** with explicit visual checklist text
- **Candidate verification strengthened** using local caption-based story-word coverage
- **Retry logic strengthened** when:
  - action coverage is low
  - scene coverage is low
  - object coverage is low
  - emotion coverage is low
  - white-bear color/identity coverage is low
- **Selection logs expanded** so each chosen frame stores word-coverage diagnostics
