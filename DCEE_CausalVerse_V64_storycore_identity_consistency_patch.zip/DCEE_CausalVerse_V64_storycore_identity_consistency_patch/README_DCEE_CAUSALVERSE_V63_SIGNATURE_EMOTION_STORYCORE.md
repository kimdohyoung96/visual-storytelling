# DCEE-CausalVerse V63 — Signature / Emotion / Story-Core Patch

## Goal
Improve frame generation so that each image reflects the generated story more faithfully, especially:
- JSON `signature_items` visibility (e.g. `honey jar`)
- generated story sentence + caption coverage
- readable protagonist facial emotion
- whole-sentence story-core realization in one frame

## Main fixes
1. **Signature-item hardening**
   - added signature-item coverage scoring and stronger penalties for missing signature items
   - added `signature` retry variant for regeneration

2. **Facial emotion strengthening**
   - added face-emotion visibility scoring
   - added `emotion_face` retry variant
   - prompts now explicitly require readable facial emotion while preserving the full scene

3. **Story-core completeness**
   - prompts now emphasize that protagonist identity, action, signature item, setting, and emotional cause/result must appear together
   - stronger candidate gating and retry policy for story-grounded frames

## Run
```bash
python run_v63.py \
  --config configs/config_v63_signature_emotion_storycore.yaml \
  --input examples/white_bear_text_only_v63.json \
  --out outputs/DCEE_v63_white_bear_text_only
```
