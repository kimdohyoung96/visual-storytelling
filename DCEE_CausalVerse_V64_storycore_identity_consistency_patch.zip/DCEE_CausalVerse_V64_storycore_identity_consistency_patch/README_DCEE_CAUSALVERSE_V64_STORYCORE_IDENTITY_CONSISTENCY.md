# DCEE-CausalVerse V64 — Story-core + Identity-consistency Patch

## What V64 strengthens

V64 focuses on the exact problems observed in V63.2:

1. **Some frames ignored part of the generated story sentence**
   - Added a **story-core contract** so the prompt explicitly requires: protagonist + action + signature item + setting + readable facial emotion in one frame.

2. **`signature_items` / caption / story details were partially omitted**
   - Added stronger signature-item wording and stronger reranking priority for sentence completeness, signature coverage, and critical nouns.

3. **Facial emotion was weak**
   - Added explicit emotion-to-face/pose mappings (anxious, frustrated, hopeful, relieved, joyful, content).

4. **Protagonist consistency drifted across frames**
   - Strengthened continuity prompt, stronger anchor usage, and stronger IP-Adapter scale when anchor references are available.

5. **Selected frame sometimes had good aesthetics but weak story faithfulness**
   - Candidate selection now prioritizes story-core metrics more strongly.

## Main code changes

- `frame_director.py`
  - added story-core visual contract
  - added explicit facial-expression / body-pose emotion contract
  - injected story-core directives into the frame prompt

- `sdxl_cross_attention_generator.py`
  - added `storycore` and `signature_emotion` prompt variants
  - strengthened strict-frame prompt text
  - allowed stronger anchor use in strict story-frame mode

- `pipeline_crossattn_butterfly.py`
  - stronger candidate gate weighting
  - stronger best-candidate tie-breaks
  - added `storycore` rescue variant

- `evaluator.py`
  - expanded honey-jar signature synonyms
  - expanded readable-emotion keywords

## Run

```bash
python run_v64.py \
  --config configs/config_v64_storycore_identity_consistency.yaml \
  --input examples/white_bear_text_only_v64.json \
  --out outputs/DCEE_v64_white_bear_text_only
```
