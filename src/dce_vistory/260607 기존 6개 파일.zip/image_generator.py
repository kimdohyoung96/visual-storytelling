from pathlib import Path
from typing import Any, Dict, List

from PIL import Image, ImageDraw

from .schema import CandidateImage


class BaseImageGenerator:
    def generate(self, prompt: str, frame_id: int, out_dir: Path, num_candidates: int = 1) -> List[CandidateImage]:
        raise NotImplementedError


class PlaceholderImageGenerator(BaseImageGenerator):
    def __init__(self, width: int = 1024, height: int = 1024):
        self.width = width
        self.height = height

    def generate(self, prompt: str, frame_id: int, out_dir: Path, num_candidates: int = 1) -> List[CandidateImage]:
        out_dir.mkdir(parents=True, exist_ok=True)
        candidates = []
        for cid in range(num_candidates):
            img = Image.new('RGB', (self.width, self.height), color=(246, 246, 246))
            draw = ImageDraw.Draw(img)
            draw.text((40, 40), f'DCE-ViStory Frame {frame_id} Candidate {cid}', fill=(0, 0, 0))
            draw.text((40, 100), self._wrap(prompt, width=75)[:1800], fill=(0, 0, 0))
            path = out_dir / f'frame_{frame_id:03d}_cand_{cid:02d}.png'
            img.save(path)
            candidates.append(CandidateImage(frame_id=frame_id, candidate_id=cid, image_path=str(path), prompt=prompt))
        return candidates

    @staticmethod
    def _wrap(text: str, width: int = 80) -> str:
        words = text.split()
        lines, cur = [], []
        for w in words:
            if sum(len(x) + 1 for x in cur) + len(w) > width:
                lines.append(' '.join(cur))
                cur = [w]
            else:
                cur.append(w)
        if cur:
            lines.append(' '.join(cur))
        return '\n'.join(lines)


class SDXLImageGenerator(BaseImageGenerator):
    def __init__(self, model_id: str = 'stabilityai/stable-diffusion-xl-base-1.0', device: str = 'cuda', width: int = 1024, height: int = 1024, num_inference_steps: int = 30, guidance_scale: float = 7.0):
        import torch
        from diffusers import StableDiffusionXLPipeline
        self.width = width
        self.height = height
        self.num_inference_steps = num_inference_steps
        self.guidance_scale = guidance_scale
        self.pipe = StableDiffusionXLPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if device.startswith('cuda') else torch.float32, use_safetensors=True)
        self.pipe.to(device)

    def generate(self, prompt: str, frame_id: int, out_dir: Path, num_candidates: int = 1) -> List[CandidateImage]:
        out_dir.mkdir(parents=True, exist_ok=True)
        candidates = []
        for cid in range(num_candidates):
            image = self.pipe(prompt=prompt, width=self.width, height=self.height, num_inference_steps=self.num_inference_steps, guidance_scale=self.guidance_scale).images[0]
            path = out_dir / f'frame_{frame_id:03d}_cand_{cid:02d}.png'
            image.save(path)
            candidates.append(CandidateImage(frame_id=frame_id, candidate_id=cid, image_path=str(path), prompt=prompt))
        return candidates


def build_image_generator(cfg: Dict[str, Any]) -> BaseImageGenerator:
    provider = cfg.get('provider', 'placeholder')
    if provider == 'placeholder':
        return PlaceholderImageGenerator(int(cfg.get('width', 1024)), int(cfg.get('height', 1024)))
    return SDXLImageGenerator(cfg.get('model_id', 'stabilityai/stable-diffusion-xl-base-1.0'), cfg.get('device', 'cuda'), int(cfg.get('width', 1024)), int(cfg.get('height', 1024)), int(cfg.get('num_inference_steps', 30)), float(cfg.get('guidance_scale', 7.0)))
