from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List

from .llm import BaseLLM, BaseVLM
from .prompts import (
    SYSTEM_NARRATIVE,
    SYSTEM_VLM,
    eval_questions_prompt,
    vlm_eval_prompt,
    ending_candidate_eval_prompt,
)
from .schema import DCEPlan, EmotionArc, StoryboardFrame, CandidateImage
from .utils import extract_json, make_contact_sheet


def compact_storyboard(storyboard: List[StoryboardFrame]) -> List[Dict[str, Any]]:
    """
    평가용 LLM/VLM에는 frame.prompt를 보내지 않는다.
    prompt를 보내면 context가 매우 커지고, memory 누적으로 폭발한다.
    """
    rows = []
    for f in storyboard:
        rows.append(
            {
                "frame_id": f.frame_id,
                "caption": f.caption,
                "narrative_function": f.narrative_function,
                "event": f.event,
                "protagonist_state": f.protagonist_state,
                "desire_link": f.desire_link,
                "conflict_level": f.conflict_level,
                "emotion": f.emotion,
                "emotion_intensity": f.emotion_intensity,
                "visual_focus": f.visual_focus,
                "key_objects": f.key_objects,
                "facial_cue": f.facial_cue,
                "body_cue": f.body_cue,
                "event_cue": f.event_cue,
                "scene_cue": f.scene_cue,
                "cinematic_cue": f.cinematic_cue,
            }
        )
    return rows


class DCEQAEvaluator:
    def __init__(
        self,
        llm: BaseLLM,
        vlm: BaseVLM,
        use_vlm: bool = True,
        save_contact_sheet: bool = True,
    ):
        self.llm = llm
        self.vlm = vlm
        self.use_vlm = use_vlm
        self.save_contact_sheet = save_contact_sheet

    def generate_questions(
        self,
        dce_plan: DCEPlan,
        emotion_arc: EmotionArc,
        storyboard: List[StoryboardFrame],
    ) -> Dict[str, Any]:
        safe_storyboard = compact_storyboard(storyboard)

        text = self.llm.generate(
            SYSTEM_NARRATIVE,
            eval_questions_prompt(
                asdict(dce_plan),
                asdict(emotion_arc),
                safe_storyboard,
            ),
            temperature=0.0,
            max_tokens=1500,
        )

        try:
            return extract_json(text)
        except Exception:
            return {
                "global_questions": [
                    "Do the frames form a coherent story?",
                    "Is the protagonist's desire visible?",
                    "Is the conflict visually visible?",
                    "Is the emotion arc visually clear?",
                    "Is the ending emotion clearly shown?",
                ],
                "frame_questions": {
                    str(f.frame_id): [
                        f"Does frame {f.frame_id} express the planned emotion '{f.emotion}'?",
                        f"Does frame {f.frame_id} show its event: {f.event}?",
                    ]
                    for f in storyboard
                },
                "ending_questions": [
                    f"Does the final frame express {dce_plan.target_ending_emotion}?",
                    "Does the final frame visually resolve the conflict?",
                    "Does the final frame show the protagonist reaching the planned ending state?",
                ],
            }

    def rerank_ending_candidates(
        self,
        final_frame: StoryboardFrame,
        dce_plan: DCEPlan,
        candidates: List[CandidateImage],
    ) -> List[CandidateImage]:
        if not candidates:
            return candidates

        if not self.use_vlm:
            for c in candidates:
                c.scores = self._heuristic_candidate_score(final_frame, dce_plan)
            return sorted(candidates, key=lambda x: x.scores.get("overall", 0.0), reverse=True)

        safe_final_frame = compact_storyboard([final_frame])[0]

        text = self.vlm.generate_with_images(
            SYSTEM_VLM,
            ending_candidate_eval_prompt(safe_final_frame, asdict(dce_plan)),
            [c.image_path for c in candidates],
            temperature=0.0,
            max_tokens=1500,
        )

        try:
            data = extract_json(text)
            score_rows = data.get("candidate_scores", [])
            score_map = {int(x["candidate_id"]): x for x in score_rows if "candidate_id" in x}

            for c in candidates:
                row = score_map.get(int(c.candidate_id), {})
                c.scores.update(
                    {
                        "ending_emotion_accuracy": float(row.get("ending_emotion_accuracy", 0.0)),
                        "visual_clarity": float(row.get("visual_clarity", 0.0)),
                        "overall": float(row.get("overall", 0.0)),
                    }
                )
                c.notes["reason"] = row.get("reason", "")

        except Exception:
            for c in candidates:
                c.scores = self._heuristic_candidate_score(final_frame, dce_plan)

        return sorted(candidates, key=lambda x: x.scores.get("overall", 0.0), reverse=True)

    def evaluate_sequence(
        self,
        dce_plan: DCEPlan,
        emotion_arc: EmotionArc,
        storyboard: List[StoryboardFrame],
        images: List[CandidateImage],
        questions: Dict[str, Any],
        out_dir: str | Path | None = None,
    ) -> Dict[str, Any]:
        if not images:
            return {"warning": "No images to evaluate."}

        contact_sheet_path = None
        if self.save_contact_sheet and out_dir:
            try:
                contact_sheet_path = make_contact_sheet(
                    [x.image_path for x in images],
                    Path(out_dir) / "contact_sheet.png",
                )
            except Exception:
                contact_sheet_path = None

        if not self.use_vlm:
            data = self._heuristic_eval(dce_plan, emotion_arc, storyboard)
            if contact_sheet_path:
                data["contact_sheet_path"] = contact_sheet_path
            return data

        safe_storyboard = compact_storyboard(storyboard)
        eval_paths = [contact_sheet_path] if contact_sheet_path else [x.image_path for x in images]

        text = self.vlm.generate_with_images(
            SYSTEM_VLM,
            vlm_eval_prompt(
                asdict(dce_plan),
                asdict(emotion_arc),
                safe_storyboard,
                questions,
            ),
            eval_paths,
            temperature=0.0,
            max_tokens=1500,
        )

        try:
            data = extract_json(text)
        except Exception:
            data = self._heuristic_eval(dce_plan, emotion_arc, storyboard)

        if contact_sheet_path:
            data["contact_sheet_path"] = contact_sheet_path

        return data

    @staticmethod
    def _heuristic_candidate_score(
        final_frame: StoryboardFrame,
        dce_plan: DCEPlan,
    ) -> Dict[str, float]:
        target = dce_plan.target_ending_emotion.lower()
        emotion = final_frame.emotion.lower()

        ending_acc = 0.80
        if target in emotion:
            ending_acc = 0.95
        elif target == "happy" and emotion in ["joy", "relief", "happiness"]:
            ending_acc = 0.90
        elif target == "sad" and emotion in ["sadness", "grief", "regret"]:
            ending_acc = 0.90
        elif target == "anger" and emotion in ["anger", "rage", "frustration"]:
            ending_acc = 0.90
        elif target == "fear" and emotion in ["fear", "anxiety", "terror"]:
            ending_acc = 0.90

        visual_clarity = 0.75
        overall = (ending_acc + visual_clarity) / 2.0

        return {
            "ending_emotion_accuracy": ending_acc,
            "visual_clarity": visual_clarity,
            "overall": overall,
        }

    @staticmethod
    def _heuristic_eval(
        dce_plan: DCEPlan,
        emotion_arc: EmotionArc,
        storyboard: List[StoryboardFrame],
    ) -> Dict[str, Any]:
        last = storyboard[-1] if storyboard else None

        ending_match = 0.65
        if last:
            target = dce_plan.target_ending_emotion.lower()
            emotion = last.emotion.lower()

            if target in emotion:
                ending_match = 0.95
            elif target == "happy" and emotion in ["joy", "relief", "happiness"]:
                ending_match = 0.90
            elif target == "sad" and emotion in ["sadness", "grief", "regret"]:
                ending_match = 0.90
            elif target == "anger" and emotion in ["anger", "rage", "frustration"]:
                ending_match = 0.90
            elif target == "fear" and emotion in ["fear", "anxiety", "terror"]:
                ending_match = 0.90

        return {
            "text_image_alignment": 0.70,
            "character_consistency": 0.70,
            "desire_alignment": 0.82 if dce_plan.desire else 0.45,
            "conflict_visibility": 0.78 if dce_plan.conflict else 0.45,
            "emotion_arc_accuracy": 0.80 if emotion_arc.states else 0.45,
            "ending_emotion_accuracy": ending_match,
            "narrative_coherence": 0.80 if len(storyboard) > 1 else 0.65,
            "interestingness": 0.78,
            "rationale": "Heuristic fallback evaluation.",
        }