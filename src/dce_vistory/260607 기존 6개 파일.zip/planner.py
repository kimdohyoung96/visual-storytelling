from dataclasses import asdict
from typing import Any, Dict, List

from .llm import BaseLLM
from .schema import StorySeed, DCEPlan, EmotionArc, StoryboardFrame, ImageUnderstanding
from .prompts import SYSTEM_NARRATIVE, story_seed_prompt, story_abstract_prompt, dce_plan_prompt, emotion_arc_prompt, storyboard_prompt
from .utils import extract_json


class DCEPlanner:
    def __init__(self, llm: BaseLLM, temperature: float = 0.4, max_tokens: int = 2500):
        self.llm = llm
        self.temperature = temperature
        self.max_tokens = max_tokens

    def build_seed(self, sample: Dict[str, Any], image_summary: ImageUnderstanding | None) -> StorySeed:
        text = self.llm.generate(SYSTEM_NARRATIVE, story_seed_prompt(sample, asdict(image_summary) if image_summary else None), temperature=self.temperature, max_tokens=self.max_tokens)
        data = extract_json(text)
        return StorySeed(image_summary=image_summary, text_prompt=sample.get('text_prompt', ''), protagonist=sample.get('protagonist', ''), target_ending_emotion=sample.get('target_ending_emotion', ''), genre=sample.get('genre', ''), style=sample.get('style', ''), setting=data.get('setting', image_summary.setting if image_summary else ''), objects=data.get('objects', image_summary.objects if image_summary else []), characters=data.get('characters', image_summary.characters if image_summary else []), mood=data.get('mood', image_summary.mood if image_summary else ''), visual_symbols=data.get('visual_symbols', {}), raw_input=sample)

    def generate_abstract(self, seed: StorySeed) -> str:
        return self.llm.generate(SYSTEM_NARRATIVE, story_abstract_prompt(asdict(seed)), temperature=self.temperature, max_tokens=900).strip()

    def generate_dce_plan(self, seed: StorySeed, abstract: str) -> DCEPlan:
        text = self.llm.generate(SYSTEM_NARRATIVE, dce_plan_prompt(asdict(seed), abstract), temperature=self.temperature, max_tokens=self.max_tokens)
        data = extract_json(text)
        return DCEPlan(protagonist=data.get('protagonist', seed.protagonist), desire=data.get('desire', ''), fear=data.get('fear', ''), misbelief=data.get('misbelief', ''), obstacle=data.get('obstacle', ''), conflict=data.get('conflict', ''), event_spine=data.get('event_spine', []), turning_point=data.get('turning_point', ''), target_ending_emotion=data.get('target_ending_emotion', seed.target_ending_emotion), ending_state=data.get('ending_state', ''), moral_or_theme=data.get('moral_or_theme', ''))

    def generate_emotion_arc(self, seed: StorySeed, abstract: str, dce_plan: DCEPlan, num_frames: int) -> EmotionArc:
        text = self.llm.generate(SYSTEM_NARRATIVE, emotion_arc_prompt(asdict(seed), abstract, asdict(dce_plan), num_frames), temperature=self.temperature, max_tokens=self.max_tokens)
        data = extract_json(text)
        states = data.get('states', [])
        intensities = data.get('intensities', [])
        if len(states) != num_frames:
            states = (states + [dce_plan.target_ending_emotion] * num_frames)[:num_frames]
        if len(intensities) != num_frames:
            intensities = (intensities + [3] * num_frames)[:num_frames]
        return EmotionArc(states=states, intensities=[int(x) for x in intensities], rationale=data.get('rationale', ''))

    def generate_storyboard(self, seed: StorySeed, abstract: str, dce_plan: DCEPlan, emotion_arc: EmotionArc) -> List[StoryboardFrame]:
        num_frames = len(emotion_arc.states)
        text = self.llm.generate(SYSTEM_NARRATIVE, storyboard_prompt(asdict(seed), abstract, asdict(dce_plan), asdict(emotion_arc), num_frames), temperature=self.temperature, max_tokens=self.max_tokens)
        rows = extract_json(text)
        if isinstance(rows, dict):
            rows = rows.get('storyboard', rows.get('frames', rows))
        if not isinstance(rows, list):
            raise ValueError(f'Storyboard must be a list, got {type(rows)}: {rows}')
        frames = []
        for idx, row in enumerate(rows):
            frames.append(StoryboardFrame(frame_id=int(row.get('frame_id', idx + 1)), caption=row.get('caption', ''), narrative_function=row.get('narrative_function', ''), event=row.get('event', ''), protagonist_state=row.get('protagonist_state', ''), desire_link=row.get('desire_link', ''), conflict_level=int(row.get('conflict_level', 1)), emotion=row.get('emotion', emotion_arc.states[min(idx, len(emotion_arc.states)-1)]), emotion_intensity=int(row.get('emotion_intensity', emotion_arc.intensities[min(idx, len(emotion_arc.intensities)-1)])), visual_focus=row.get('visual_focus', ''), key_objects=row.get('key_objects', []), facial_cue=row.get('facial_cue', ''), body_cue=row.get('body_cue', ''), event_cue=row.get('event_cue', ''), scene_cue=row.get('scene_cue', ''), cinematic_cue=row.get('cinematic_cue', '')))
        return frames
