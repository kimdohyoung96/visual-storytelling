SYSTEM_NARRATIVE = """
You are a research-grade multimodal narrative planner.
You must explicitly model protagonist desire, conflict, event progression, emotion change, and ending emotion.
Return concise valid JSON whenever JSON is requested.
"""

SYSTEM_VLM = """
You are a visual narrative evaluator.
Return concise valid JSON whenever JSON is requested.
"""


def image_understanding_prompt(image_path: str, sample: dict) -> str:
    return f"""
Describe the input image for multimodal story planning.
Focus on characters, setting, objects, mood, and a plot hint.
Input image path: {image_path}
Text prompt: {sample.get('text_prompt')}
Protagonist: {sample.get('protagonist')}
Target ending emotion: {sample.get('target_ending_emotion')}
Return JSON with caption, characters, setting, objects, mood, inferred_plot_hint.
"""


def story_seed_prompt(sample: dict, image_summary: dict | None) -> str:
    return f"""
Create a multimodal story seed.
Text prompt: {sample.get('text_prompt')}
Protagonist: {sample.get('protagonist')}
Target ending emotion: {sample.get('target_ending_emotion')}
Genre: {sample.get('genre')}
Style: {sample.get('style')}
Image summary: {image_summary}
Return JSON with setting, objects, characters, mood, visual_symbols.
"""


def story_abstract_prompt(seed: dict) -> str:
    return f"""
Write a story abstract in 4-6 sentences.
Seed:
{seed}
Requirements:
- introduce the protagonist desire
- introduce a meaningful conflict
- make the ending compatible with the target ending emotion
- keep it visually drawable
"""


def dce_plan_prompt(seed: dict, abstract: str) -> str:
    return f"""
Create a DCE plan (Desire, Conflict, Ending / Event progression).
Seed:
{seed}
Story abstract:
{abstract}
Return JSON with protagonist, desire, fear, misbelief, obstacle, conflict, event_spine, turning_point, target_ending_emotion, ending_state, moral_or_theme.
"""


def emotion_arc_prompt(seed: dict, abstract: str, dce_plan: dict, num_frames: int) -> str:
    return f"""
Create an emotion arc planner with exactly {num_frames} steps.
Seed:
{seed}
Story abstract:
{abstract}
DCE plan:
{dce_plan}
Return JSON with states, intensities, rationale.
"""


def storyboard_prompt(seed: dict, abstract: str, dce_plan: dict, emotion_arc: dict, num_frames: int) -> str:
    return f"""
Create a {num_frames}-frame storyboard.
Seed:
{seed}
Abstract:
{abstract}
DCE plan:
{dce_plan}
Emotion arc:
{emotion_arc}
Return a JSON array. Each item must include:
frame_id, caption, narrative_function, event, protagonist_state, desire_link, conflict_level,
emotion, emotion_intensity, visual_focus, key_objects, facial_cue, body_cue, event_cue, scene_cue, cinematic_cue.
The last frame must clearly express the target ending emotion.
"""


def frame_prompt(frame: dict, dce_plan: dict, emotion_arc: dict, memory: dict, style: str, input_image_summary: dict | None) -> str:
    return f"""
Generate one frame of a visual story.
Frame caption: {frame.get('caption')}
Narrative function: {frame.get('narrative_function')}
Event: {frame.get('event')}
Protagonist state: {frame.get('protagonist_state')}
Desire link: {frame.get('desire_link')}
Conflict level: {frame.get('conflict_level')}
Emotion: {frame.get('emotion')} (intensity {frame.get('emotion_intensity')}/5)
Emotion visual cues:
- facial cue: {frame.get('facial_cue')}
- body cue: {frame.get('body_cue')}
- event cue: {frame.get('event_cue')}
- scene cue: {frame.get('scene_cue')}
- cinematic cue: {frame.get('cinematic_cue')}
DCE plan: {dce_plan}
Emotion arc: {emotion_arc}
Input image summary: {input_image_summary}
Narrative memory: {memory}
Visual style: {style}
Preserve protagonist identity, reflect frame event, express emotion with facial/body/scene/cinematic cues, and remain consistent with prior frames.
"""


def eval_questions_prompt(dce_plan: dict, emotion_arc: dict, storyboard: list) -> str:
    return f"""
Generate evaluation questions for visual story assessment.
DCE plan: {dce_plan}
Emotion arc: {emotion_arc}
Storyboard: {storyboard}
Return JSON with global_questions, frame_questions, ending_questions.
"""


def vlm_eval_prompt(dce_plan: dict, emotion_arc: dict, storyboard: list, questions: dict) -> str:
    return f"""
Evaluate the generated visual story by looking at the images.
DCE plan: {dce_plan}
Emotion arc: {emotion_arc}
Storyboard: {storyboard}
Questions: {questions}
Return JSON with text_image_alignment, character_consistency, desire_alignment, conflict_visibility, emotion_arc_accuracy, ending_emotion_accuracy, narrative_coherence, interestingness, rationale.
"""


def ending_candidate_eval_prompt(final_frame: dict, dce_plan: dict) -> str:
    return f"""
Evaluate ending candidates for the final frame.
Final frame specification: {final_frame}
DCE plan: {dce_plan}
Return JSON with candidate_scores where each item has candidate_id, ending_emotion_accuracy, visual_clarity, overall, reason.
"""
