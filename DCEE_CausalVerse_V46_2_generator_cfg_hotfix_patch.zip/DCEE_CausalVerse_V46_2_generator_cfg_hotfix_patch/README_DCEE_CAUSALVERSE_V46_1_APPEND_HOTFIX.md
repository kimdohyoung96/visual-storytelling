# DCEE-CausalVerse V46.1 Append Hotfix

## Fixed error
V46 had a Python list API bug in `frame_director.py`:

```python
directives.append('...', '...')
```

`list.append()` accepts exactly one argument, so V46 crashed before image generation.

V46.1 splits it into two append calls:

```python
directives.append('the image should be readable at a glance as the current sentence of the story')
directives.append('use a literal storybook depiction rather than a decorative animal portrait')
```

## Core changed file
- `src/dce_vistory/frame_director.py`

## Recommended run
```bash
python run_v46_1.py \
  --config configs/config_v46_1_append_hotfix.yaml \
  --input examples/white_bear_text_only_v46_1.json \
  --out outputs/DCEE_v46_1_white_bear_text_only
```

You can also keep using `run_v46.py` after replacing `frame_director.py`.
