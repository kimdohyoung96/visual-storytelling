# DCEE-CausalVerse V43 sentence-locked story patch

## Why V43 was created
V42 improved hard noun grounding, but outputs still often became **generic pretty bear scenes** instead of literal realizations of each frame sentence.

V43 makes the text-only path even stricter:
- every text-only candidate is generated through a **sentence-locked story route**,
- candidate variants focus on **action / object / scene** while keeping the same sentence,
- frame-state penalties are stronger,
- retry logic is more aggressive when the selected frame still looks generic.

## Main changes

### 1. `frame_director.py`
Adds stronger sentence-to-frame directives:
- `sentence_lock`
- `frame_phase`
- richer hard directives for enter / search / discover / retrieve / savor
- stronger avoid-list for wrong stage leakage

### 2. `sdxl_cross_attention_generator.py`
For text-only runs, V43 now:
- forces all candidates through `text_story`
- uses sentence-locked variants:
  - `action`
  - `object`
  - `scene`
- explicitly tells SDXL to avoid generic portraits and decorative scenes

### 3. `evaluator.py`
Adds stronger penalties for:
- missing search behavior
- missing underbrush / roots / lake / jar
- wrong animal type
- "cute cub" or unrelated animal substitutions
- savor / retrieve actions not being visible

### 4. `pipeline_crossattn_butterfly.py`
Adds stronger text-only settings:
- more candidates in text-only mode
- higher text-only story thresholds
- second-stage regeneration when first retry still fails
- forces sentence-lock-only regeneration on retries

## New files
- `run_v43.py`
- `config_v43_sentence_locked_story.yaml`
- `examples/white_bear_text_only_v43.json`

## Recommended run command
```bash
python run_v43.py   --config configs/config_v43_sentence_locked_story.yaml   --input examples/white_bear_text_only_v43.json   --out outputs/DCEE_v43_white_bear_text_only
```
