# DCEE-CausalVerse V44.1 hotfix

## Fixed error
`TypeError: can only concatenate list (not "str") to list` in `sdxl_cross_attention_generator.py`.

## Cause
`_llm_render_plan_variant_segments(...)` returned `variant_avoid` as a string because `_join_unique(...)` returns a joined prompt string. Later `_build_prompt_pair(...)` tried to concatenate it with `hard_avoid`, which is a list.

## Fix
- Make `must_not` / `variant_avoid` a list of cleaned strings.
- Add robust normalization before building `hard_avoid_text`.

## Core modified file
- `src/dce_vistory/sdxl_cross_attention_generator.py`

## Recommended run
```bash
python run_v44_1.py \
  --config configs/config_v44_1_llm_frame_prompt_hotfix.yaml \
  --input examples/white_bear_text_only_v44.json \
  --out outputs/DCEE_v44_1_white_bear_text_only
```
