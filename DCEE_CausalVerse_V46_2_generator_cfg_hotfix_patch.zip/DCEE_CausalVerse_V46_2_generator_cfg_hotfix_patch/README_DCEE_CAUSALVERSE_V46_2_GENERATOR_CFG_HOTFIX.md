# DCEE-CausalVerse V46.2 Generator Config Hotfix

Fixes `AttributeError: SDXLButterflyCrossAttentionGenerator object has no attribute cfg`.

## Root cause
V46 introduced consistent-frame seeding using `self.cfg`, but the image generator class does not store the full config as `self.cfg`.

## Fix
- Adds `consistent_identity_seed_across_frames` as an explicit constructor argument.
- Stores it as `self.consistent_identity_seed_across_frames`.
- Replaces `self.cfg.get(...)` with `getattr(self, 'consistent_identity_seed_across_frames', True)`.
- Passes the option from `pipeline_crossattn_butterfly.py`.

## Run
```bash
python run_v46_2.py \
  --config configs/config_v46_2_generator_cfg_hotfix.yaml \
  --input examples/white_bear_text_only_v46_2.json \
  --out outputs/DCEE_v46_2_white_bear_text_only
```
