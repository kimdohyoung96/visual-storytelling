# DCEE-CausalVerse V42 hard frame grounding patch

## Why V42 was created
V41.3 improved the results after removing `image_path`, which strongly suggests that the previous input image conditioning was interfering with story-faithful generation. However, V41.3 still produced images that were often **generic bear-in-forest scenes** rather than exact realizations of each story sentence.

V42 strengthens the mapping from **generated story sentence -> exact frame image**.

## Main idea
For each frame, V42 builds a **hard frame contract**:
- what must be shown,
- what should be avoided,
- what the current action is,
- what nouns must appear,
- what scene stage the frame is in.

Then the image prompt explicitly says to render **this exact moment only**.

## Main changes
### 1. `frame_director.py`
Adds `_story_frame_directives(...)` to infer:
- `must_show`
- `must_avoid`
- `directives`

Examples:
- roots / stumbling -> show tangled roots and off-balance pose
- bushes -> show thick bushes and searching pose
- lake -> show visible lake or lakeshore
- sees jar -> show jar visible at water edge
- retrieves jar -> show bear touching or holding the jar

These are stored into:
- `hard_visual_directives`
- `must_avoid_elements`
- `frame_goal`

### 2. `sdxl_cross_attention_generator.py`
Adds **V42 hard frame grounding** prompt strategy.
The prompt now emphasizes:
- `frame goal`
- current sentence only
- current action only
- visible required nouns
- hard directives
- avoid elements

### 3. `evaluator.py`
Adds `_frame_state_penalty(...)`.
This penalizes images/captions that fail to express the current frame state, e.g.:
- root frame with no roots
- bush-search frame with no bushes
- lake frame with no lake/water
- jar frame with no jar
- retrieval frame with no retrieval action

### 4. `pipeline_crossattn_butterfly.py`
Keeps the V41.3 text-only hotfix behavior and updates policy labeling for V42.

### 5. New run/config files
- `run_v42.py`
- `config_v42_hard_frame_grounding.yaml`
- `examples/white_bear_text_only_v42.json`

## Recommended run command
```bash
python run_v42.py   --config configs/config_v42_hard_frame_grounding.yaml   --input examples/white_bear_text_only_v42.json   --out outputs/DCEE_v42_white_bear_text_only
```
