# DCEE-CausalVerse V44 — LLM Frame Prompt Grounding

## Why V44 chooses LLM frame-level prompt generation instead of persona-only generation

V43 already tried to strengthen sentence grounding, but the remaining failure mode was **not mainly identity consistency**. The white bear identity was partly preserved, but the generated images still failed on:

1. **frame-specific object state** (e.g. honey jar missing vs. visible vs. being retrieved vs. being savored)
2. **background stage correctness** (forest / underbrush / roots / lake / reeds)
3. **action readability** (searching, navigating roots, spotting, retrieving, savoring)
4. **preventing generic cute-animal illustrations**

A persona-only approach helps mostly with **who** the protagonist is. It does **not reliably solve what must happen in this exact frame**.

Therefore, V44 adopts the stronger method for the paper:

- keep a **persona anchor** as a sub-component
- but make the main control signal an **LLM-generated per-frame render plan**

## Main V44 changes

- `pipeline_crossattn_butterfly.py`
  - adds `_generate_llm_render_plan(...)`
  - for each frame, asks the LLM to output JSON with:
    - `persona_anchor`
    - `action_pose`
    - `object_state`
    - `environment`
    - `must_show`
    - `must_not_show`
    - `prompt_core`
    - `prompt_detail`
    - `negative_prompt`
  - stores all frame plans into `llm_render_plans.json`

- `sdxl_cross_attention_generator.py`
  - if `llm_render_plan` exists, text-only generation uses that plan directly
  - action / object / scene candidate variants are still used, but now they are derived from the LLM render plan rather than only heuristic sentence parsing

## New outputs

- `llm_render_plans.json`
- `generation_policy_V44_llm_frame_prompt.json`

## Expected benefit

Compared with V43, V44 should improve:

- exact story-to-image faithfulness
- noun grounding
- action/background stability
- correct object-stage realization

## How to run

```bash
python run_v44.py \
  --config config_v44_llm_frame_prompt.yaml \
  --input examples/white_bear_text_only_v44.json \
  --output outputs/v44_white_bear
```

## Practical note for the paper

If you describe the method section, position V44 as:

> Persona is retained as an identity prior, but the primary control signal is a frame-level LLM render plan that explicitly specifies action, object state, and environment for each story sentence.
