# DCEE-CausalVerse V46 Token-Safe Identity + Scene Grounding

## What changed
- Hard token-safe trimming for SDXL prompts to avoid CLIP length overflow warnings degrading prompt fidelity.
- Stronger canonical protagonist anchor for the white bear (creamy white fur, rounded ears, black nose/eyes, large paws, stocky body).
- Text-only mode now reuses the **previous selected frame image path** as an optional identity continuity anchor in metadata for later frames.
- More compact scene/background prompt clauses so important nouns (honey jar, underbrush, lake, foliage) survive prompt fitting.
- Optional consistent seed across frames to reduce protagonist drift.

## Expected effect
- Fewer long-prompt truncation issues.
- Better frame-to-frame protagonist consistency.
- Stronger literal scene grounding for noun-critical frames.
